'use client';

import { useState, useEffect } from 'react';
import { SiteHeader } from '@/components/site-header';
import { SidebarNav } from '@/components/sidebar-nav';
import { ArrowUp } from 'lucide-react';
import { cn } from '@/lib/utils';

export function DocsLayout({ children }: { children: React.ReactNode }) {
  const [menuOpen, setMenuOpen] = useState(false);
  const [showBackToTop, setShowBackToTop] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setShowBackToTop(window.scrollY > 400);
    };
    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <div className="min-h-screen flex flex-col">
      <SiteHeader onMenuToggle={() => setMenuOpen(!menuOpen)} menuOpen={menuOpen} />
      <div className="flex flex-1">
        {/* Mobile sidebar overlay */}
        {menuOpen && (
          <div
            className="fixed inset-0 z-30 bg-black/50 lg:hidden"
            onClick={() => setMenuOpen(false)}
          />
        )}

        {/* Sidebar */}
        <aside
          className={cn(
            'fixed top-14 left-0 bottom-0 z-40 w-72 overflow-y-auto border-r border-border bg-background transition-transform duration-300',
            'lg:translate-x-0 lg:static lg:z-auto',
            menuOpen ? 'translate-x-0' : '-translate-x-full'
          )}
        >
          <SidebarNav onClose={() => setMenuOpen(false)} />
        </aside>

        {/* Main content */}
        <main className="flex-1 min-w-0 lg:pl-0">
          <div className="max-w-4xl mx-auto px-4 sm:px-6 py-8 lg:px-8">
            {children}
          </div>
        </main>
      </div>

      {/* Back to top button */}
      <button
        onClick={scrollToTop}
        aria-label="Kembali ke atas"
        className={cn(
          'fixed bottom-6 left-6 z-50 flex items-center justify-center w-10 h-10 rounded-full bg-primary text-primary-foreground shadow-lg transition-all duration-300 hover:bg-primary/90 hover:scale-110',
          showBackToTop ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-4 pointer-events-none'
        )}
      >
        <ArrowUp className="h-4 w-4" />
      </button>
    </div>
  );
}

'use client';

import { useState } from 'react';
import { Copy, Check } from 'lucide-react';
import { cn } from '@/lib/utils';

interface LegalQuoteProps {
  title?: string;
  children: React.ReactNode;
  className?: string;
}

export function LegalQuote({ title, children, className }: LegalQuoteProps) {
  const [copied, setCopied] = useState(false);

  const handleCopy = () => {
    const text = typeof children === 'string' ? children : '';
    if (text) {
      navigator.clipboard.writeText(text);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    }
  };

  return (
    <div className={cn('legal-quote group relative', className)}>
      {title && (
        <p className="text-xs font-semibold text-blue-600 dark:text-blue-400 mb-1 not-italic">{title}</p>
      )}
      <div className="italic text-foreground/90">{children}</div>
      <button
        onClick={handleCopy}
        className="absolute top-2 right-2 opacity-0 group-hover:opacity-100 transition-opacity p-1 rounded hover:bg-blue-100 dark:hover:bg-blue-900"
        title="Salin kutipan"
      >
        {copied ? <Check className="h-3.5 w-3.5 text-green-500" /> : <Copy className="h-3.5 w-3.5 text-blue-500" />}
      </button>
    </div>
  );
}

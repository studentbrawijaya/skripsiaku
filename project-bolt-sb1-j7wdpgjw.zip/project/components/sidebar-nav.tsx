'use client';

import Link from 'next/link';
import { usePathname } from 'next/navigation';
import { BookOpen, Chrome as Home, BookMarked, Scale, Gavel, FileText, Table2, ChevronDown, ChevronRight } from 'lucide-react';
import { useState } from 'react';
import { cn } from '@/lib/utils';

const navItems = [
  {
    href: '/',
    label: 'Beranda',
    icon: Home,
  },
  {
    href: '/bab-1',
    label: 'Bab I – Pendahuluan',
    icon: BookOpen,
    children: [
      { href: '/bab-1#latar-belakang', label: 'Latar Belakang' },
      { href: '/bab-1#orisinalitas', label: 'Orisinalitas Penelitian' },
      { href: '/bab-1#rumusan-masalah', label: 'Rumusan Masalah' },
      { href: '/bab-1#tujuan', label: 'Tujuan Penelitian' },
      { href: '/bab-1#manfaat', label: 'Manfaat Penelitian' },
      { href: '/bab-1#metode', label: 'Metode Penelitian' },
      { href: '/bab-1#definisi', label: 'Definisi Konseptual' },
    ],
  },
  {
    href: '/bab-2',
    label: 'Bab II – Kajian Pustaka',
    icon: BookMarked,
    children: [
      { href: '/bab-2#positivisme', label: 'Positivisme Hukum' },
      { href: '/bab-2#welfare-state', label: 'Negara Kesejahteraan' },
      { href: '/bab-2#konstitusi-ekonomi', label: 'Konstitusi Ekonomi' },
      { href: '/bab-2#kepabeanan', label: 'Tinjauan Kepabeanan' },
      { href: '/bab-2#kondisi-darurat', label: 'Kondisi Darurat' },
      { href: '/bab-2#tujuan-bernegara', label: 'Tujuan Bernegara RI' },
    ],
  },
  {
    href: '/bab-3',
    label: 'Bab III – Pembahasan',
    icon: Scale,
    children: [
      { href: '/bab-3#paradigma', label: 'Paradigma Kepabeanan' },
      { href: '/bab-3#legal-order', label: 'Legal Order Kepabeanan' },
      { href: '/bab-3#frasa-darurat', label: 'Frasa "Darurat"' },
      { href: '/bab-3#covid19', label: 'Pandemi COVID-19' },
      { href: '/bab-3#krisis-2008', label: 'Krisis Global 2008' },
      { href: '/bab-3#bencana-nasional', label: 'Bencana Nasional' },
      { href: '/bab-3#krisis-moneter', label: 'Krisis Moneter 1999' },
      { href: '/bab-3#krisis-1985', label: 'Krisis Kelembagaan 1985' },
      { href: '/bab-3#antinomi', label: 'Antinomi Pengaturan' },
      { href: '/bab-3#hukum-ideal', label: 'Menuju Hukum Ideal' },
    ],
  },
  {
    href: '/bab-4',
    label: 'Bab IV – Penutup',
    icon: Gavel,
    children: [
      { href: '/bab-4#kesimpulan', label: 'Kesimpulan' },
      { href: '/bab-4#saran', label: 'Saran' },
    ],
  },
  {
    href: '/pustaka',
    label: 'Daftar Pustaka',
    icon: FileText,
  },
  {
    href: '/tabel',
    label: 'Tabel & Figur',
    icon: Table2,
  },
];

function NavItem({ item, onClose }: { item: typeof navItems[0]; onClose?: () => void }) {
  const pathname = usePathname();
  const isActive = pathname === item.href || (item.href !== '/' && pathname.startsWith(item.href));
  const [expanded, setExpanded] = useState(isActive);
  const Icon = item.icon;

  return (
    <div>
      <div className="flex items-center gap-1">
        <Link
          href={item.href}
          onClick={onClose}
          className={cn(
            'sidebar-link flex-1',
            isActive && 'active'
          )}
        >
          <Icon className="h-4 w-4 shrink-0" />
          <span className="flex-1">{item.label}</span>
        </Link>
        {item.children && (
          <button
            onClick={() => setExpanded(!expanded)}
            className="p-1 rounded hover:bg-accent transition-colors"
          >
            {expanded ? <ChevronDown className="h-3 w-3" /> : <ChevronRight className="h-3 w-3" />}
          </button>
        )}
      </div>
      {item.children && expanded && (
        <div className="ml-6 mt-0.5 space-y-0.5 border-l border-border pl-3">
          {item.children.map((child) => (
            <Link
              key={child.href}
              href={child.href}
              onClick={onClose}
              className="block py-1 text-xs text-muted-foreground hover:text-foreground transition-colors"
            >
              {child.label}
            </Link>
          ))}
        </div>
      )}
    </div>
  );
}

export function SidebarNav({ onClose }: { onClose?: () => void }) {
  return (
    <nav className="py-4 px-3 space-y-1">
      <div className="px-3 py-2 mb-2">
        <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wider">Navigasi</p>
      </div>
      {navItems.map((item) => (
        <NavItem key={item.href} item={item} onClose={onClose} />
      ))}
    </nav>
  );
}

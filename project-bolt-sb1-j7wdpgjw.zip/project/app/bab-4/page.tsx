import { DocsLayout } from '@/components/docs-layout';
import { Gavel } from 'lucide-react';

export default function Bab4Page() {
  return (
    <DocsLayout>
      <div className="mb-8">
        <div className="flex items-center gap-2 text-sm text-muted-foreground mb-3">
          <Gavel className="h-4 w-4" />
          <span>Bab IV</span>
        </div>
        <h1 className="text-3xl font-bold text-foreground mb-2" style={{ fontFamily: 'var(--font-merriweather)' }}>
          Penutup
        </h1>
        <p className="text-muted-foreground">Kesimpulan dan saran dari penelitian</p>
      </div>

      <div className="space-y-10">

        {/* Kesimpulan */}
        <section id="kesimpulan" className="scroll-mt-20">
          <h2 className="text-xl font-bold text-foreground mb-5" style={{ fontFamily: 'var(--font-merriweather)' }}>
            4.1 Kesimpulan
          </h2>

          <p className="text-base leading-relaxed text-foreground/90 mb-5" style={{ textAlign: 'justify' }}>
            Berdasarkan penelitian yang telah dilakukan terhadap dinamika pengaturan hukum kepabeanan Indonesia dalam kondisi darurat dan analisis normatif tentang pengaturan yang ideal, dapat ditarik dua kesimpulan pokok sebagai berikut:
          </p>

          <div className="space-y-5">
            <div className="p-5 rounded-xl border border-border bg-card">
              <div className="flex gap-3">
                <div className="w-8 h-8 rounded-full bg-primary text-primary-foreground text-sm font-bold flex items-center justify-center shrink-0">1</div>
                <div>
                  <h3 className="text-base font-semibold text-foreground mb-2">
                    Dinamika Pengaturan Hukum Kepabeanan dalam Kondisi Darurat
                  </h3>
                  <p className="text-sm text-muted-foreground leading-relaxed mb-3" style={{ textAlign: 'justify' }}>
                    Dinamika pengaturan hukum kepabeanan dalam kondisi darurat di Indonesia dari tahun 2006 hingga 2025 menunjukkan pola respons yang bersifat reaktif, temporal, dan sangat bergantung pada inisiatif eksekutif. Pengaturan kepabeanan dalam berbagai kondisi darurat mulai dari bencana nasional 2004-2006, krisis ekonomi global 2008, hingga darurat kesehatan 2020-2023 selalu dilakukan melalui Peraturan Menteri Keuangan (PMK) dan Peraturan Pemerintah (PP). Dinamika ini mengungkap tiga permasalahan yaitu adanya kekaburan norma mengenai frasa "darurat" dalam UU Pabean yang hanya mengakui force majeure sarana pengangkut (Pasal 7A). Kemudian fasilitas kepabeanan hanya ditujukan untuk keadaan darurat berupa bencana alam (Pasal 25 ayat (1) huruf d), sementara rezim kedaruratan nasional yang lebih luas mencakup bencana non-alam, krisis ekonomi, dan keadaan bahaya sebagaimana diatur dalam UUD NRI 1945 dan UU Penanggulangan Bencana. Kedua, instrumen fiskal darurat seperti Bea Masuk Ditanggung Pemerintah (BM DTP) tidak diatur sebelumnya dalam UU Pabean dan hanya diatur melalui Peraturan Menteri Keuangan, sehingga berpotensi melanggar asas legalitas Pasal 23A UUD NRI 1945 serta menimbulkan ketidakpastian hukum dan risiko ultra vires. Ketiga, dominasi kewenangan eksekutif dalam merespons kondisi darurat dengan menerbitkan puluhan Peraturan Menteri Keuangan untuk BM DTP, pembebasan bea masuk vaksin, dan relaksasi prosedur kepabeanan, tidak diimbangi oleh mekanisme pengawasan legislatif yang memadai dan parameter batasan waktu yang jelas, sehingga kebijakan darurat cenderung bersifat tanpa kepastian hukum.
                  </p>
                 
                </div>
              </div>
            </div>

            <div className="p-5 rounded-xl border border-border bg-card">
              <div className="flex gap-3">
                <div className="w-8 h-8 rounded-full bg-primary text-primary-foreground text-sm font-bold flex items-center justify-center shrink-0">2</div>
                <div>
                  <h3 className="text-base font-semibold text-foreground mb-2">
                    Pengaturan Hukum Kepabeanan Darurat yang Ideal
                  </h3>
                   <p className="text-sm text-muted-foreground leading-relaxed mb-3" style={{ textAlign: 'justify' }}>
                    Pengaturan hukum kepabeanan dalam kondisi darurat yang sesuai dengan tujuan negara Republik Indonesia harus direformulasi dengan mengintegrasikan prinsip-prinsip konstitusi ekonomi, negara kesejahteraan  dan positivisme hukum modern ke dalam UU Pabean. Pengaturan kepabeanan darurat yang ideal harus memuat lima prinsip dasar yakni prinsip legalitas, prinsip proporsionalita, prinsip akuntabilitas, prinsip transparansi, dan prinsip perlindungan hak asasi manusia. Dalam keadaan darurat Negara tidak boleh mengorbankan hak-hak fundamental warga negara, khususnya hak ekonomi dan hak atas kesejahteraan. Reformulasi tersebut dilakukan dengan melakukan merevisi Pasal 25 ayat (1) huruf d UU Pabean dengan mengganti frasa "bencana alam" menjadi "bencana" sesuai definisi UU Penanggulangan Bencana serta menambahkan rujukan eksplisit ke UU Prp 23/1959 tentang Keadaan Bahaya; kemudian perlu adanya pengakuan dan pengaturan BM DTP sebagai jenis bea masuk tersendiri dalam UU Pabean berikut syarat-syarat, prosedur, batasan waktu, dan mekanisme pengawasannya. Selanjutnya perlu adanya penetapan kriteria objektif untuk mendeklarasikan kondisi darurat yang memerlukan relaksasi kepabeanan. Perubahan paradigma UU Pabean dari enforcement-oriented menjadi service-oriented yang responsif terhadap praktik bisnis modern, digitalisasi dokumen, dan kebutuhan fasilitasi perdagangan tanpa mengorbankan fungsi pengawasan dan perlindungan kepentingan nasional. Dengan reformulasi ini, hukum berfungsi sebagai first line of economic defense sekaligus humanitarian facilitator yang konstitusional, akuntabel, dan responsif terhadap berbagai kondisi darurat sehingga selaras dengan tujuan negara untuk melindungi segenap bangsa dan memajukan kesejahteraan umum.
                  </p>
                 
                 
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* Saran */}
        <section id="saran" className="scroll-mt-20">
          <h2 className="text-xl font-bold text-foreground mb-5" style={{ fontFamily: 'var(--font-merriweather)' }}>
            4.2 Saran
          </h2>

          <p className="text-base leading-relaxed text-foreground/90 mb-5" style={{ textAlign: 'justify' }}>
            Berdasarkan temuan dan kesimpulan penelitian, berikut dikemukakan saran-saran yang ditujukan kepada berbagai pemangku kepentingan:
          </p>

          <div className="space-y-5">

            <div className="p-5 rounded-xl border border-border bg-card">
              <div className="flex items-center gap-2 mb-3">
                <div className="w-6 h-6 rounded bg-blue-100 dark:bg-blue-900/40 text-blue-700 dark:text-blue-300 text-xs font-bold flex items-center justify-center">A</div>
                <h3 className="text-base font-semibold text-foreground">Kepada DPR dan Pemerintah (Pembentuk Undang-Undang)</h3>
              </div>
              <ol className="text-sm text-muted-foreground space-y-2 list-decimal pl-5">
                <li>
                  <strong className="text-foreground"> Merevisi UU No. 17 Tahun 2006 tentang Kepabeanan</strong> dengan menambahkan bab atau pasal-pasal khusus yang mengatur secara komprehensif tentang kepabeanan dalam kondisi darurat, termasuk: definisi "kondisi darurat," kriteria dan mekanisme penetapan status darurat yang berdampak pada kepabeanan, hierarki tindakan kepabeanan darurat, dan mekanisme akuntabilitas penggunaan fasilitas kepabeanan darurat.
                </li>
                <li>
                  <strong className="text-foreground">Melakukan harmonisasikan terminologi "darurat" di seluruh ketentuan UU Kepabeanan</strong> agar tidak lagi terjadi inkonsistensi antara Pasal 7A ayat (6) dengan Pasal 25 ayat (1) huruf d dan ketentuan-ketentuan lainnya.
                </li>
                <li>
                  <strong className="text-foreground">Mempertimbangkan pembentukan Peraturan Pemerintah Pengganti Undang-Undang (Perpu)</strong> sebagai langkah interim untuk mengatur kepabeanan darurat secara komprehensif sambil menunggu proses revisi UU Kepabeanan diselesaikan.
                </li>
              </ol>
            </div>

            <div className="p-5 rounded-xl border border-border bg-card">
              <div className="flex items-center gap-2 mb-3">
                <div className="w-6 h-6 rounded bg-emerald-100 dark:bg-emerald-900/40 text-emerald-700 dark:text-emerald-300 text-xs font-bold flex items-center justify-center">B</div>
                <h3 className="text-base font-semibold text-foreground">Kepada Kementerian Keuangan dan DJBC</h3>
              </div>
              <ol className="text-sm text-muted-foreground space-y-2 list-decimal pl-5">
                <li>
                  <strong className="text-foreground">Membentuk Tim Gugus Tugas Kepabeanan Darurat</strong> yang bersifat permanen dan lintas direktorat, yang bertugas menyiapkan dan memelihara rencana darurat kepabeanan (customs emergency plan) yang dapat diaktifkan segera saat terjadi kondisi darurat.
                </li>
                <li>
                  <strong className="text-foreground">Mengembangkan sistem teknologi informasi kepabeanan darurat</strong> yang memungkinkan proses clearance dipercepat secara digital tanpa harus mengeluarkan PMK baru setiap kali terjadi darurat.
                </li>
                <li>
                  <strong className="text-foreground">Menyusun dan publikasikan Panduan Kepabeanan Darurat</strong> yang komprehensif bagi importir, eksportir, pengangkut, dan lembaga kemanusiaan, sehingga mereka dapat memahami hak dan kewajiban kepabeanan mereka dalam kondisi darurat.
                </li>
                <li>
                  <strong className="text-foreground">Memperkuat koordinasi dengan BNPB, BPBD, dan Kemensos</strong> untuk memastikan sinkronisasi antara penetapan status bencana/darurat dengan aktivasi mekanisme kepabeanan yang sesuai.
                </li>
              </ol>
            </div>

            <div className="p-5 rounded-xl border border-border bg-card">
              <div className="flex items-center gap-2 mb-3">
                <div className="w-6 h-6 rounded bg-amber-100 dark:bg-amber-900/40 text-amber-700 dark:text-amber-300 text-xs font-bold flex items-center justify-center">C</div>
                <h3 className="text-base font-semibold text-foreground">Kepada Akademisi dan Peneliti</h3>
              </div>
              <ol className="text-sm text-muted-foreground space-y-2 list-decimal pl-5">
                <li>
                  <strong className="text-foreground">Mengembangkan penelitian empiris</strong> tentang dampak kebijakan kepabeanan darurat terhadap efektivitas distribusi bantuan kemanusiaan dan pemulihan ekonomi pasca-bencana di Indonesia.
                </li>
                <li>
                  <strong className="text-foreground">Melakukan kajian komparatif yang lebih mendalam</strong> dengan negara-negara ASEAN dan Asia Pasifik yang telah memiliki mekanisme kepabeanan darurat yang lebih matang, untuk mengidentifikasi praktik terbaik yang dapat diadopsi Indonesia.
                </li>
                <li>
                  <strong className="text-foreground">Memperkuat kajian tentang interaksi antara hukum kepabeanan dan hukum kebencanaan</strong> sebagai dua sistem hukum yang semakin sering bersinggungan namun belum terharmonisasi secara memadai.
                </li>
              </ol>
            </div>

            <div className="p-5 rounded-xl border border-border bg-card">
              <div className="flex items-center gap-2 mb-3">
                <div className="w-6 h-6 rounded bg-rose-100 dark:bg-rose-900/40 text-rose-700 dark:text-rose-300 text-xs font-bold flex items-center justify-center">D</div>
                <h3 className="text-base font-semibold text-foreground">Kepada Masyarakat dan Organisasi Kemanusiaan</h3>
              </div>
              <ol className="text-sm text-muted-foreground space-y-2 list-decimal pl-5">
                <li>
                  <strong className="text-foreground">Aktif berpartisipasi dalam konsultasi publik</strong> terkait revisi UU Kepabeanan, khususnya untuk memastikan bahwa kepentingan masyarakat penerima manfaat bantuan darurat terwakili dalam proses pembentukan undang-undang.
                </li>
                <li>
                  <strong className="text-foreground">Menyusun rencana kepabeanan pra-bencana</strong> untuk organisasi kemanusiaan yang aktif di Indonesia, sehingga pada saat terjadi bencana, prosedur impor barang bantuan dapat berjalan lebih cepat dan terarah.
                </li>
              </ol>
            </div>
          </div>
        </section>

        {/* Penutup */}
        <div className="p-6 rounded-xl border border-primary/20 bg-primary/5 text-center">
         
        </div>
      </div>
    </DocsLayout>
  );
}

import { DocsLayout } from '@/components/docs-layout';
import { LegalQuote } from '@/components/legal-quote';
import { Scale, SquareCheck as CheckSquare } from 'lucide-react';

const legalOrderData = [
  { level: 1, jenis: 'UUD NRI 1945', contoh: 'Pasal 23A', dasar: 'Grundnorm / norma tertinggi', catatan: 'Legitimasi tertinggi' },
  { level: 2, jenis: 'Undang-Undang', contoh: 'UU No. 10/1995 jo. 17/2006 jo. 7/2021', dasar: 'Pasal 20 UUD 1945', catatan: 'Regulasi pokok kepabeanan' },
  { level: 3, jenis: 'Peraturan Pemerintah', contoh: '22 PP di bidang kepabeanan', dasar: 'Pasal 5(2) UUD 1945', catatan: 'Aturan pelaksana UU' },
  { level: 4, jenis: 'Peraturan Presiden', contoh: 'Perpres pengesahan RKC, dll.', dasar: 'Pasal 4(1) UUD 1945', catatan: 'Termasuk pengesahan konvensi internasional' },
  { level: 5, jenis: 'Peraturan Daerah Provinsi', contoh: 'Perda Kep. Riau, Papua Barat, Kalbar, Kaltim', dasar: 'Pasal 18 UUD 1945', catatan: 'Tegahan kepabeanan sebagai BMD' },
  { level: 6, jenis: 'Peraturan Daerah Kab/Kota', contoh: 'Perda Kab. Halmahera Timur, Kudus, Agam, dll.', dasar: 'Pasal 18 UUD 1945', catatan: 'Tegahan kepabeanan + opsen impor' },
];

const ppKepabeanan = [
  { no: 1, nomor: 'PP 36/2023 jo. PP 8/2025', tentang: 'Devisa Hasil Ekspor dari Kegiatan Pengusahaan, Pengelolaan, dan/atau Pengolahan Sumber Daya Alam' },
  { no: 2, nomor: 'PP 44/2025', tentang: 'Tata Cara Penetapan Tarif, Pengelolaan, dan Penyelesaian Keberatan PNBP' },
  { no: 3, nomor: 'PP 12/2023 jo. PP 29/2024', tentang: 'Pemberian Perizinan Berusaha, Kemudahan Berusaha, dan Fasilitas Penanaman Modal di IKN' },
  { no: 4, nomor: 'PP 49/2022', tentang: 'PPN Dibebaskan dan PPN/PPnBM Tidak Dipungut atas Impor Tertentu' },
  { no: 5, nomor: 'PP 28/2022', tentang: 'Pengurusan Piutang Negara oleh Panitia Urusan Piutang Negara' },
  { no: 6, nomor: 'PP 15/2022', tentang: 'Perlakuan Perpajakan dan/atau PNBP di Bidang Usaha Pertambangan Batubara' },
  { no: 7, nomor: 'PP 40/2021', tentang: 'Penyelenggaraan Kawasan Ekonomi Khusus' },
  { no: 8, nomor: 'PP 37/2018', tentang: 'Perlakuan Perpajakan dan/atau PNBP di Bidang Usaha Pertambangan Mineral' },
  { no: 9, nomor: 'PP 20/2017', tentang: 'Pengendalian Impor atau Ekspor Barang yang Diduga Merupakan atau Berasal dari Hasil Pelanggaran HKI' },
  { no: 10, nomor: 'PP 32/2009 jo. PP 85/2015', tentang: 'Tempat Penimbunan Berikat' },
  { no: 11, nomor: 'PP 55/2008', tentang: 'Pengenaan Bea Keluar terhadap Barang Ekspor' },
  { no: 12, nomor: 'PP 28/2008 jo. PP 39/2019', tentang: 'Pengenaan Sanksi Administrasi Berupa Denda di Bidang Kepabeanan' },
  { no: 13, nomor: 'PP 23/2008', tentang: 'Peran Serta Lembaga Internasional dan Lembaga Asing Non Pemerintah dalam Penanggulangan Bencana' },
  { no: 14, nomor: 'PP 21/2008', tentang: 'Penyelenggaraan Penanggulangan Bencana' },
  { no: 15, nomor: 'PP 48/2007 jo. PP 40/2017', tentang: 'Kawasan Perdagangan Bebas dan Pelabuhan Bebas Karimun' },
  { no: 16, nomor: 'PP 47/2007 jo. PP 41/2017', tentang: 'Kawasan Perdagangan Bebas dan Pelabuhan Bebas Bintan' },
  { no: 17, nomor: 'PP 46/2007 jo. PP 39/2024', tentang: 'Kawasan Ekonomi Khusus Pariwisata dan Kesehatan Internasional Batam' },
  { no: 18, nomor: 'PP 35/2007', tentang: 'Pengalokasian Sebagian Pendapatan Badan Usaha untuk Peningkatan Kemampuan Perekayasaan Inovasi dan Difusi Teknologi' },
  { no: 19, nomor: 'PP 68/2021', tentang: 'Kawasan Ekonomi Khusus Nongsa' },
  { no: 20, nomor: 'PP 67/2021', tentang: 'Kawasan Ekonomi Khusus Batam Aero Technic' },
  { no: 21, nomor: 'PP 55/1996 jo. PP 54/2023', tentang: 'Penghentian Penyidikan Tindak Pidana di Bidang Cukai untuk Kepentingan Penerimaan Negara' },
  { no: 22, nomor: 'PP 21/1996', tentang: 'Penindakan di Bidang Kepabeanan' },
];

const perpresKepabeanan = [
  { nomor: 'Perpres 69/2014', tentang: 'Pengesahan International Convention on the Simplification and Harmonization of Customs Procedures (Revised Kyoto Convention)' },
  { nomor: 'Perpres 128/2018', tentang: 'Pengesahan Persetujuan antara RI dan Armenia tentang Pembebasan Visa bagi Pemegang Paspor Diplomatik/Dinas' },
  { nomor: 'Perpres 158/2024', tentang: 'Kementerian Keuangan' },
  { nomor: 'Perpres 61/2024', tentang: 'Neraca Komoditas' },
  { nomor: 'Perpres 107/2015 jo. 93/2021', tentang: 'Percepatan Penyelenggaraan Prasarana dan Sarana Kereta Cepat Jakarta-Bandung' },
  { nomor: 'Perpres 105/2015', tentang: 'Kunjungan Kapal Wisata (Yacht) Asing ke Indonesia' },
];

const perdaProvinsi = [
  { nomor: 'Provinsi Kepulauan Riau No. 1/2015', tentang: 'Customs bond' },
  { nomor: 'Provinsi Papua Barat No. 4/2013', tentang: 'Rencana Tata Ruang Wilayah 2013-2033 (mendukung infrastruktur pelayanan kepabeanan)' },
  { nomor: 'Provinsi Kalimantan Barat No. 3/2019', tentang: 'Mengakui tegahan kepabeanan sebagai Barang Milik Daerah' },
  { nomor: 'Provinsi Kalimantan Timur No. 3/2022', tentang: 'Mengakui tegahan kepabeanan sebagai Barang Milik Daerah' },
  { nomor: 'Provinsi Papua Barat No. 2/2007', tentang: 'Mengakui tegahan kepabeanan sebagai Barang Milik Daerah' },
];

const perdaKabKota = [
  { nomor: 'Kab. Halmahera Timur No. 3/2022', tentang: 'Tegahan kepabeanan sebagai Barang Milik Daerah' },
  { nomor: 'Kab. Kudus No. 3/2010', tentang: 'Tegahan kepabeanan sebagai Barang Milik Daerah' },
  { nomor: 'Kab. Agam No. 2/2020', tentang: 'Tegahan kepabeanan sebagai Barang Milik Daerah' },
  { nomor: 'Kab. Grobogan No. 4/2008', tentang: 'Tegahan kepabeanan sebagai Barang Milik Daerah' },
  { nomor: 'Kab. Lebak No. 3/2022', tentang: 'Tegahan kepabeanan sebagai Barang Milik Daerah' },
  { nomor: 'Kab. Kepulauan Anambas No. 4/2017', tentang: 'Tegahan kepabeanan sebagai Barang Milik Daerah' },
  { nomor: 'Kab. Nagan Raya No. 2/2019', tentang: 'Tegahan kepabeanan + fasilitas kepabeanan untuk pembangunan daerah' },
  { nomor: 'Kab. Ende No. 4/2017', tentang: 'Tegahan kepabeanan sebagai Barang Milik Daerah' },
  { nomor: 'Kab. Bantaeng No. 3/2023', tentang: 'Opsen daerah menyasar barang impor' },
  { nomor: 'Kab. Brebes No. 10/2021', tentang: 'Fasilitas kepabeanan untuk pembangunan daerah' },
];

const putusanMK = [
  { nomor: '113/PUU-XIII/2015', amar: 'Menolak seluruhnya' },
  { nomor: '80/PUU-XII/2014', amar: 'Menolak seluruhnya' },
  { nomor: '12/PUU-VII/2009', amar: 'Tidak dapat diterima' },
];

const perbedaanDarurat = [
  {
    aspek: 'Pasal yang mengatur',
    pasal7a: 'Pasal 7A ayat (6) UU No. 17/2006',
    pasal25: 'Pasal 25 ayat (1) huruf d UU No. 17/2006',
  },
  {
    aspek: 'Frasa yang digunakan',
    pasal7a: '"dalam keadaan darurat"',
    pasal25: '"bencana alam" (tidak menyebut "darurat" secara eksplisit)',
  },
  {
    aspek: 'Subjek/objek',
    pasal7a: 'Sarana pengangkut dan barang impor yang dibawa',
    pasal25: 'Barang kiriman hadiah/hibah untuk penanggulangan bencana alam',
  },
  {
    aspek: 'Konsekuensi hukum',
    pasal7a: 'Diperbolehkan membongkar barang tanpa persetujuan pejabat bea cukai terlebih dahulu',
    pasal25: 'Pembebasan bea masuk atas barang yang bersangkutan',
  },
  {
    aspek: 'Sifat ketentuan',
    pasal7a: 'Prosedural (pengecualian prosedur bongkar muat)',
    pasal25: 'Substantif (pembebasan kewajiban fiskal)',
  },
  {
    aspek: 'Definisi darurat',
    pasal7a: 'Tidak didefinisikan dalam UU',
    pasal25: 'Merujuk pada "bencana alam" yang didefinisikan dalam UU No. 24/2007',
  },
  {
    aspek: 'Mekanisme aktivasi',
    pasal7a: 'Inisiatif pengangkut; dilaporkan segera setelah membongkar',
    pasal25: 'Permohonan pembebasan kepada Menteri Keuangan',
  },
];

const kerangkaCovid: { no: string; pmk: string; isi: string; status: string }[] = [
  { no: '1', pmk: 'PMK No. 34/PMK.04/2020', isi: 'Fasilitas kepabeanan dan cukai dalam rangka penanggulangan COVID-19', status: 'Dicabut' },
  { no: '2', pmk: 'PMK No. 31/PMK.04/2020', isi: 'Pembebasan bea masuk dan cukai atas impor barang penanganan COVID-19', status: 'Dicabut' },
  { no: '3', pmk: 'PMK No. 68/PMK.04/2020', isi: 'Tata cara pemberian fasilitas kepabeanan dan/atau cukai atas impor barang untuk penanggulangan pandemi COVID-19', status: 'Dicabut' },
  { no: '4', pmk: 'PMK No. 134/PMK.04/2020', isi: 'Perubahan atas PMK No. 68 — perluasan ruang lingkup barang dan fasilitas', status: 'Dicabut' },
  { no: '5', pmk: 'PMK No. 188/PMK.04/2020', isi: 'Perubahan PMK No. 134 — penyesuaian daftar barang dan persyaratan', status: 'Dicabut' },
  { no: '6', pmk: 'PMK No. 68/PMK.04/2021', isi: 'Fasilitas kepabeanan dan/atau cukai serta perpajakan atas impor pengadaan vaksin COVID-19 dan pengadaan obat', status: 'Dicabut' },
  { no: '7', pmk: 'PMK No. 45/PMK.04/2022', isi: 'Pencabutan PMK-PMK terkait fasilitas COVID-19 seiring dengan pemulihan kondisi', status: 'Berlaku' },
  { no: '8', pmk: 'PMK No. 92/PMK.04/2021', isi: 'Perpanjangan fasilitas impor barang untuk penanganan pandemi COVID-19', status: 'Dicabut' },
];

const pmkKrisis2008: { no: string; pmk: string; komoditas: string }[] = [
  { no: '1', pmk: 'PMK No. 241/PMK.011/2008', komoditas: 'Produk industri manufaktur tertentu' },
  { no: '2', pmk: 'PMK No. 242/PMK.011/2008', komoditas: 'Mesin industri' },
  { no: '3', pmk: 'PMK No. 243/PMK.011/2008', komoditas: 'Peralatan telekomunikasi' },
  { no: '4', pmk: 'PMK No. 244/PMK.011/2008', komoditas: 'Suku cadang otomotif' },
  { no: '5', pmk: 'PMK No. 245/PMK.011/2008', komoditas: 'Bahan baku industri kimia' },
  { no: '6', pmk: 'PMK No. 246/PMK.011/2008', komoditas: 'Produk tekstil dan pakaian' },
  { no: '7', pmk: 'PMK No. 247/PMK.011/2008', komoditas: 'Produk perikanan' },
  { no: '8', pmk: 'PMK No. 248/PMK.011/2008', komoditas: 'Produk pertanian tertentu' },
  { no: '9', pmk: 'PMK No. 249/PMK.011/2008', komoditas: 'Produk elektronik konsumer' },
  { no: '10', pmk: 'PMK No. 250/PMK.011/2008', komoditas: 'Bahan baku industri kertas' },
  { no: '11', pmk: 'PMK No. 251/PMK.011/2008', komoditas: 'Produk industri berbasis karet' },
  { no: '12', pmk: 'PMK No. 252/PMK.011/2008', komoditas: 'Barang modal industri' },
  { no: '13', pmk: 'PMK No. 253/PMK.011/2008', komoditas: 'Produk industri kulit' },
  { no: '14', pmk: 'PMK No. 254/PMK.011/2008', komoditas: 'Bahan baku industri besi baja' },
  { no: '15', pmk: 'PMK No. 255/PMK.011/2008', komoditas: 'Produk aluminium' },
  { no: '16', pmk: 'PMK No. 256/PMK.011/2008', komoditas: 'Komponen elektronik' },
  { no: '17', pmk: 'PMK No. 257/PMK.011/2008', komoditas: 'Produk kayu olahan' },
  { no: '18', pmk: 'PMK No. 258/PMK.011/2008', komoditas: 'Bahan kimia dasar' },
  { no: '19', pmk: 'PMK No. 120/PMK.011/2009', komoditas: 'Produk farmasi dan alat kesehatan' },
  { no: '20', pmk: 'PMK No. 121/PMK.011/2009', komoditas: 'Produk pertambangan tertentu' },
  { no: '21', pmk: 'PMK No. 122/PMK.011/2009', komoditas: 'Bahan baku kendaraan bermotor' },
  { no: '22', pmk: 'PMK No. 123/PMK.011/2009', komoditas: 'Komponen mesin pertanian' },
  { no: '23', pmk: 'PMK No. 124/PMK.011/2009', komoditas: 'Produk industri mainan' },
  { no: '24', pmk: 'PMK No. 125/PMK.011/2009', komoditas: 'Bahan baku tekstil (serat)' },
  { no: '25', pmk: 'PMK No. 126/PMK.011/2009', komoditas: 'Peralatan konstruksi' },
  { no: '26', pmk: 'PMK No. 127/PMK.011/2009', komoditas: 'Komponen energi terbarukan' },
  { no: '27', pmk: 'PMK No. 128/PMK.011/2009', komoditas: 'Bahan baku industri plastik' },
  { no: '28', pmk: 'PMK No. 129/PMK.011/2009', komoditas: 'Produk percetakan dan penerbitan' },
  { no: '29', pmk: 'PMK No. 130/PMK.011/2009', komoditas: 'Komponen alat berat' },
  { no: '30', pmk: 'PMK No. 131/PMK.011/2009', komoditas: 'Bahan baku industri kaca' },
  { no: '31', pmk: 'PMK No. 132/PMK.011/2009', komoditas: 'Produk industri keramik' },
  { no: '32', pmk: 'PMK No. 151/PMK.011/2009', komoditas: 'Paku (tindakan safeguard)' },
  { no: '33', pmk: 'PMK No. 133/PMK.011/2009', komoditas: 'Dextrose monohydrate (tindakan safeguard)' },
];

const pmkBencana: { pmk: string; bencana: string; isi: string; status: string }[] = [
  { pmk: 'PMK No. 95/PMK.04/2006', bencana: 'Gempa Yogyakarta 2006', isi: 'Pembebasan bea masuk atas impor barang untuk penanggulangan gempa bumi di Yogyakarta dan Jawa Tengah', status: 'Berlaku' },
  { pmk: 'PMK No. 98/PMK.04/2006', bencana: 'Gempa Yogyakarta 2006', isi: 'Pengembalian bea masuk dan PPN impor atas kendaraan bermotor yang rusak akibat gempa', status: 'Berlaku' },
  { pmk: 'PMK No. 237/PMK.04/2010', bencana: 'Berbagai bencana', isi: 'Perubahan PMK tentang pembebasan bea masuk untuk penanggulangan bencana alam', status: 'Berlaku' },
  { pmk: 'PMK No. 69/PMK.04/2012', bencana: 'Berbagai bencana', isi: 'Pembebasan bea masuk atas impor barang untuk keperluan penanganan bencana alam', status: 'Berlaku' },
  { pmk: 'PMK No. 97/PMK.04/2005', bencana: 'Gempa Nias 2005', isi: 'Fasilitas kepabeanan untuk barang impor dalam rangka penanggulangan bencana gempa bumi di Nias', status: 'Berlaku' },
  { pmk: 'PMK No. 44/PMK.04/2005', bencana: 'Tsunami Aceh 2004-2005', isi: 'Fasilitas kepabeanan atas impor barang dan peralatan untuk penanggulangan bencana alam di Nanggroe Aceh Darussalam dan Sumatera Utara', status: 'Berlaku' },
];

const wcoResolutions = [
  'Customs administrations should establish procedures for the expedited clearance of relief consignments in the event of natural disasters.',
  'Customs tariff relief or suspension should be provided automatically upon declaration of emergency by competent national authorities.',
  'Documentation requirements for relief goods should be simplified and flexible during emergency periods.',
  'Coordination between customs authorities and humanitarian organizations should be established through memoranda of understanding.',
  'Customs administrations should participate in national disaster risk reduction plans and emergency response frameworks.',
  'Electronic advance data sharing should be established to enable pre-clearance of relief consignments before their arrival.',
  'Post-clearance audit mechanisms should replace prior examination for relief goods to avoid delays during emergency response.',
];

const prinsipHukumIdeal = [
  {
    no: '1',
    prinsip: 'Definisi Komprehensif "Darurat"',
    isi: 'UU Kepabeanan harus memuat definisi tunggal dan komprehensif tentang "kondisi darurat" yang mencakup bencana alam, pandemi, krisis ekonomi, dan krisis kelembagaan, disertai kriteria objektif untuk penetapan statusnya.',
  },
  {
    no: '2',
    prinsip: 'Mekanisme Respons Proporsional',
    isi: 'Harus ada hierarki respons yang proporsional: (a) respons otomatis untuk bencana yang sudah ditetapkan pemerintah, (b) respons dipercepat atas permohonan, dan (c) respons terencana melalui kesepakatan pra-darurat.',
  },
  {
    no: '3',
    prinsip: 'Keseimbangan Fungsi Fiskal dan Non-Fiskal',
    isi: 'Kebijakan kepabeanan darurat harus menyeimbangkan kepentingan penerimaan negara dengan kebutuhan fasilitasi bantuan kemanusiaan dan pemulihan ekonomi, dengan prioritas pada kebutuhan kemanusiaan.',
  },
  {
    no: '4',
    prinsip: 'Transparansi dan Akuntabilitas',
    isi: 'Setiap pembebasan atau keringanan bea masuk darurat harus dilengkapi dengan mekanisme transparansi dan akuntabilitas yang memadai, termasuk pelaporan, audit, dan evaluasi pasca-darurat.',
  },
  {
    no: '5',
    prinsip: 'Kesesuaian dengan Standar Internasional',
    isi: 'Pengaturan kepabeanan darurat harus selaras dengan standar WCO, WTO, dan perjanjian internasional lainnya yang telah diratifikasi Indonesia, sekaligus tetap mengutamakan kepentingan nasional dan tujuan bernegara.',
  },
];

export default function Bab3Page() {
  return (
    <DocsLayout>
      <div className="mb-8">
        <div className="flex items-center gap-2 text-sm text-muted-foreground mb-3">
          <Scale className="h-4 w-4" />
          <span>Bab III</span>
        </div>
        <h1 className="text-3xl font-bold text-foreground mb-2" style={{ fontFamily: 'var(--font-merriweather)' }}>
          Hasil dan Pembahasan
        </h1>
        <p className="text-muted-foreground">Dinamika pengaturan hukum kepabeanan dan perumusan hukum ideal</p>
      </div>

      <div className="space-y-12">

        {/* BAGIAN A */}
        <div>
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-blue-100 dark:bg-blue-950/40 text-blue-700 dark:text-blue-300 text-xs font-semibold mb-6">
            Bagian A — Dinamika Pengaturan Hukum Kepabeanan
          </div>

          {/* 3A.1 Paradigma */}
          <section id="paradigma" className="scroll-mt-20 mb-10">
            <h2 className="text-xl font-bold text-foreground mb-4" style={{ fontFamily: 'var(--font-merriweather)' }}>
              3A.1 Paradigma Kepabeanan Indonesia
            </h2>
            <p className="text-base leading-relaxed text-foreground/90 mb-4" style={{ textAlign: 'justify' }}>
              Paradigma kepabeanan Indonesia secara historis didominasi oleh orientasi fiskal. Lembaga kepabeanan—yang kini dikenal sebagai Direktorat Jenderal Bea dan Cukai (DJBC)—pada awal pembentukannya lebih ditekankan sebagai alat pengumpul pendapatan negara daripada fasilitator perdagangan. Warisan paradigma kolonial ini bertahan lama dan masih dapat dirasakan dalam struktur regulasi kepabeanan hingga era reformasi.
            </p>
            <p className="text-base leading-relaxed text-foreground/90 mb-4" style={{ textAlign: 'justify' }}>
              Dominasi paradigma fiskal ini memiliki implikasi yang signifikan dalam penanganan kondisi darurat. Ketika terjadi bencana atau krisis, mekanisme kepabeanan yang dirancang untuk memaksimalkan penerimaan negara menghadapi tekanan untuk beradaptasi secara cepat—sebuah adaptasi yang sering kali dilakukan secara reaktif, parsial, dan tanpa landasan sistem yang memadai.
            </p>
            <p className="text-base leading-relaxed text-foreground/90 mb-4" style={{ textAlign: 'justify' }}>
              Perbandingan dengan Singapura—yang menganut paradigma trade facilitation—menunjukkan perbedaan mencolok. Singapura memandang fungsi kepabeanan terutama sebagai fasilitator arus perdagangan yang efisien, dengan fungsi fiskal sebagai sekunder. Pendekatan ini memungkinkan Singapura untuk merespons situasi darurat dengan jauh lebih fleksibel dan cepat dibandingkan Indonesia.
            </p>
          </section>

          {/* 3A.2 Legal Order */}
          <section id="legal-order" className="scroll-mt-20 mb-10">
            <h2 className="text-xl font-bold text-foreground mb-4" style={{ fontFamily: 'var(--font-merriweather)' }}>
              3A.2 Legal Order Kepabeanan Indonesia
            </h2>
            <p className="text-base leading-relaxed text-foreground/90 mb-4" style={{ textAlign: 'justify' }}>
              Hierarki norma hukum kepabeanan Indonesia mengikuti struktur hierarki perundang-undangan yang diatur dalam UU No. 12 Tahun 2011 jo. UU 15/2019. Berikut adalah legal order kepabeanan Indonesia dari hierarki tertinggi hingga terendah:
            </p>

            {/* Piramida visual */}
            <div className="flex flex-col items-center mb-6">
              <div className="w-full max-w-lg">
                {[
                  { level: 1, label: 'UUD NRI 1945 (Pasal 23A)', bg: 'bg-blue-800 text-white', w: 'w-24' },
                  { level: 2, label: 'Undang-Undang (UU 10/1995 jo. 17/2006 jo. 7/2021)', bg: 'bg-blue-600 text-white', w: 'w-48' },
                  { level: 3, label: 'Peraturan Pemerintah (22 PP)', bg: 'bg-blue-500 text-white', w: 'w-64' },
                  { level: 4, label: 'Peraturan Presiden', bg: 'bg-blue-400 text-white', w: 'w-72' },
                  { level: 5, label: 'Peraturan Daerah Provinsi', bg: 'bg-blue-300 text-blue-900', w: 'w-80' },
                  { level: 6, label: 'Peraturan Daerah Kabupaten/Kota', bg: 'bg-blue-200 text-blue-900', w: 'w-96' },
                ].map((item) => (
                  <div key={item.level} className="flex justify-center mb-0.5">
                    <div className={`${item.w} max-w-full ${item.bg} text-xs text-center py-1.5 px-2 rounded-sm font-medium`}>
                      {item.level}. {item.label}
                    </div>
                  </div>
                ))}
              </div>
            </div>
            <p className="text-xs text-center text-muted-foreground mb-4">Gambar. Piramida Legal Order Kepabeanan Indonesia</p>

            <div className="p-4 rounded-lg border border-amber-200 dark:border-amber-800 bg-amber-50 dark:bg-amber-950/30 mb-6">
              <p className="text-sm text-amber-900 dark:text-amber-200">
                <strong>Catatan:</strong> Peraturan Menteri Keuangan (Permenkeu/PMK) tidak termasuk dalam hierarki peraturan perundang-undangan menurut UU No. 12/2011, namun banyak digunakan sebagai aturan teknis pelaksana kepabeanan. <strong>Tidak ada Peraturan Direktur Jenderal Bea dan Cukai (Peraturan DJBC)</strong> dalam hierarki ini.
              </p>
            </div>

            {/* Tabel ringkas hierarki */}
            <div className="table-responsive rounded-lg border border-border mb-6">
              <table className="legal-table">
                <thead>
                  <tr>
                    <th>Level</th>
                    <th>Jenis Peraturan</th>
                    <th>Contoh Relevan Kepabeanan</th>
                    <th>Dasar Konstitusional</th>
                    <th>Catatan</th>
                  </tr>
                </thead>
                <tbody>
                  {legalOrderData.map((row) => (
                    <tr key={row.level}>
                      <td className="text-center font-bold text-primary">{row.level}</td>
                      <td className="font-semibold">{row.jenis}</td>
                      <td className="text-xs">{row.contoh}</td>
                      <td className="text-xs">{row.dasar}</td>
                      <td className="text-xs italic">{row.catatan}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
            <p className="text-xs text-muted-foreground mb-8">Tabel. Legal Order Hukum Kepabeanan Indonesia (Sumber: analisis penulis, 2026)</p>

            {/* 22 Peraturan Pemerintah */}
            <h3 className="text-base font-semibold text-foreground mb-3">Peraturan Pemerintah di Bidang Kepabeanan (22 PP)</h3>
            <p className="text-sm text-muted-foreground mb-3">Berikut adalah seluruh Peraturan Pemerintah yang secara langsung maupun tidak langsung mengatur bidang kepabeanan:</p>
            <div className="table-responsive rounded-lg border border-border mb-6" style={{ maxHeight: '400px', overflowY: 'auto' }}>
              <table className="legal-table">
                <thead className="sticky top-0 bg-background">
                  <tr>
                    <th className="w-8">No.</th>
                    <th>Nomor PP</th>
                    <th>Tentang</th>
                  </tr>
                </thead>
                <tbody>
                  {ppKepabeanan.map((row) => (
                    <tr key={row.no}>
                      <td className="text-center">{row.no}</td>
                      <td className="font-mono text-xs font-medium">{row.nomor}</td>
                      <td className="text-xs">{row.tentang}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
            <p className="text-xs text-muted-foreground mb-8">Tabel. 22 Peraturan Pemerintah di Bidang Kepabeanan (Sumber: analisis penulis, 2026)</p>

            {/* Peraturan Presiden */}
            <h3 className="text-base font-semibold text-foreground mb-3">Peraturan Presiden Terkait Kepabeanan</h3>
            <div className="table-responsive rounded-lg border border-border mb-6">
              <table className="legal-table">
                <thead>
                  <tr>
                    <th>Nomor</th>
                    <th>Tentang</th>
                  </tr>
                </thead>
                <tbody>
                  {perpresKepabeanan.map((row) => (
                    <tr key={row.nomor}>
                      <td className="font-mono text-xs font-medium">{row.nomor}</td>
                      <td className="text-xs">{row.tentang}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
            <p className="text-xs text-muted-foreground mb-8">Tabel. Peraturan Presiden Terkait Kepabeanan (Sumber: analisis penulis, 2026)</p>

            {/* Peraturan Daerah */}
            <h3 className="text-base font-semibold text-foreground mb-3">Peraturan Daerah (Provinsi & Kabupaten/Kota)</h3>
            <div className="grid md:grid-cols-2 gap-4 mb-4">
              <div>
                <h4 className="text-sm font-semibold text-foreground mb-2">Peraturan Daerah Provinsi</h4>
                <div className="space-y-1.5">
                  {perdaProvinsi.map((row) => (
                    <div key={row.nomor} className="flex gap-2 p-2 rounded border border-border bg-card text-xs">
                      <div className="w-1.5 rounded bg-primary/60 shrink-0" />
                      <div>
                        <span className="font-semibold text-foreground">{row.nomor}</span>
                        <span className="text-muted-foreground"> — {row.tentang}</span>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
              <div>
                <h4 className="text-sm font-semibold text-foreground mb-2">Peraturan Daerah Kabupaten/Kota</h4>
                <div className="space-y-1.5">
                  {perdaKabKota.map((row) => (
                    <div key={row.nomor} className="flex gap-2 p-2 rounded border border-border bg-card text-xs">
                      <div className="w-1.5 rounded bg-emerald-500/60 shrink-0" />
                      <div>
                        <span className="font-semibold text-foreground">{row.nomor}</span>
                        <span className="text-muted-foreground"> — {row.tentang}</span>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
            <div className="p-3 rounded-lg border border-border bg-muted/30 mb-8">
              <p className="text-xs text-muted-foreground">Beberapa Perda mengakui tegahan kepabeanan sebagai Barang Milik Daerah. Pengaturan opsen daerah juga mulai menyasar barang impor.</p>
            </div>

            {/* Putusan MK */}
            <h3 className="text-base font-semibold text-foreground mb-3">Putusan Mahkamah Konstitusi (Pengujian UU Kepabeanan)</h3>
            <div className="table-responsive rounded-lg border border-border mb-4">
              <table className="legal-table">
                <thead>
                  <tr>
                    <th>Nomor Perkara</th>
                    <th>Amar Putusan</th>
                  </tr>
                </thead>
                <tbody>
                  {putusanMK.map((row) => (
                    <tr key={row.nomor}>
                      <td className="font-mono text-xs font-medium">{row.nomor}</td>
                      <td>
                        <span className={`inline-flex px-2 py-0.5 rounded-full text-xs font-medium ${row.amar === 'Menolak seluruhnya' ? 'bg-red-100 text-red-700 dark:bg-red-900/40 dark:text-red-300' : 'bg-gray-100 text-gray-500 dark:bg-gray-800 dark:text-gray-400'}`}>
                          {row.amar}
                        </span>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
            <p className="text-xs text-muted-foreground mb-4">Tabel. Putusan MK yang menguji UU No. 17/2006 terhadap UUD 1945 (Sumber: Mahkamah Konstitusi RI)</p>

            <div className="p-4 rounded-lg border border-primary/20 bg-primary/5">
              <h4 className="text-sm font-semibold text-foreground mb-2">Ringkasan Legal Order Kepabeanan</h4>
              <p className="text-sm text-muted-foreground leading-relaxed" style={{ textAlign: 'justify' }}>
                Hukum kepabeanan di Indonesia bersumber dari hierarki peraturan perundang-undangan yang dimulai dari UUD 1945 (Pasal 23A), kemudian UU Kepabeanan, 22 Peraturan Pemerintah, Peraturan Presiden, dan Peraturan Daerah. Peraturan Menteri Keuangan bersifat teknis pelaksana di luar hierarki formal. Tidak terdapat Peraturan DJBC dalam tatanan hukum kepabeanan sesuai UU No. 12/2011. Seluruh perkara MK yang menguji UU Kepabeanan beramput menolak atau tidak diterima, menunjukkan bahwa UU Kepabeanan secara konstitusional masih dianggap sah.
              </p>
            </div>
          </section>

          {/* 3A.3 Frasa Darurat */}
          <section id="frasa-darurat" className="scroll-mt-20 mb-10">
            <h2 className="text-xl font-bold text-foreground mb-4" style={{ fontFamily: 'var(--font-merriweather)' }}>
              3A.3 Permasalahan Frasa &ldquo;Darurat&rdquo; dalam UU Kepabeanan
            </h2>
            <p className="text-base leading-relaxed text-foreground/90 mb-4" style={{ textAlign: 'justify' }}>
              Salah satu kelemahan mendasar UU No. 17 Tahun 2006 adalah ketiadaan definisi yang komprehensif dan konsisten atas frasa "darurat." Kajian terhadap pasal-pasal UU Kepabeanan menemukan setidaknya dua konteks yang berbeda dalam penggunaan frasa terkait darurat:
            </p>

            <div className="grid md:grid-cols-2 gap-4 mb-6">
              <div className="p-4 rounded-lg border-2 border-blue-300 dark:border-blue-700 bg-blue-50 dark:bg-blue-950/30">
                <div className="text-xs font-semibold text-blue-600 dark:text-blue-400 mb-2">PASAL 7A AYAT (6)</div>
                <LegalQuote>
                  &ldquo;Dalam hal sarana pengangkut dalam keadaan darurat, pengangkut dapat membongkar barang impor terlebih dahulu dan pemberitahuannya dilakukan sesegera mungkin setelah keadaan darurat berakhir.&rdquo;
                </LegalQuote>
                <div className="mt-2 text-xs text-blue-700 dark:text-blue-300">
                  <span className="font-semibold">Konteks:</span> Darurat operasional sarana pengangkut
                </div>
              </div>

              <div className="p-4 rounded-lg border-2 border-amber-300 dark:border-amber-700 bg-amber-50 dark:bg-amber-950/30">
                <div className="text-xs font-semibold text-amber-600 dark:text-amber-400 mb-2">PASAL 25 AYAT (1) HURUF d</div>
                <LegalQuote className="border-amber-500">
                  &ldquo;Pembebasan bea masuk diberikan atas impor... barang kiriman hadiah/hibah untuk kepentingan penanggulangan bencana alam.&rdquo;
                </LegalQuote>
                <div className="mt-2 text-xs text-amber-700 dark:text-amber-300">
                  <span className="font-semibold">Konteks:</span> Bencana alam sebagai kondisi darurat
                </div>
              </div>
            </div>

            <h3 className="text-base font-semibold text-foreground mb-3">Tabel Perbedaan Definisi Darurat dalam UU Kepabeanan</h3>
            <div className="table-responsive rounded-lg border border-border mb-4">
              <table className="legal-table">
                <thead>
                  <tr>
                    <th>Aspek Pembanding</th>
                    <th>Pasal 7A ayat (6)</th>
                    <th>Pasal 25 ayat (1) huruf d</th>
                  </tr>
                </thead>
                <tbody>
                  {perbedaanDarurat.map((row) => (
                    <tr key={row.aspek}>
                      <td className="font-semibold text-xs">{row.aspek}</td>
                      <td className="text-xs">{row.pasal7a}</td>
                      <td className="text-xs">{row.pasal25}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
            <p className="text-xs text-muted-foreground mb-4">Tabel 2. Perbedaan Definisi Darurat dalam UU Kepabeanan (Sumber: analisis penulis, 2026)</p>

            <p className="text-base leading-relaxed text-foreground/90" style={{ textAlign: 'justify' }}>
              Inkonsistensi ini menunjukkan bahwa pembentuk undang-undang tidak memiliki konsepsi yang terpadu tentang "darurat" dalam konteks kepabeanan. Akibatnya, setiap kondisi darurat yang timbul di luar dua situasi tersebut—misalnya pandemi atau krisis ekonomi—harus ditangani melalui regulasi ad hoc yang dikeluarkan oleh eksekutif, tanpa landasan yang jelas dalam undang-undang.
            </p>
          </section>

          {/* 3A.4 COVID-19 */}
          <section id="covid19" className="scroll-mt-20 mb-10">
            <h2 className="text-xl font-bold text-foreground mb-4" style={{ fontFamily: 'var(--font-merriweather)' }}>
              3A.4 Arah Pengaturan Pandemi COVID-19 (2019–2023)
            </h2>
            <p className="text-base leading-relaxed text-foreground/90 mb-4" style={{ textAlign: 'justify' }}>
              Pandemi COVID-19 yang merebak di Indonesia sejak Maret 2020 memaksa pemerintah untuk mengeluarkan serangkaian regulasi kepabeanan darurat dalam waktu singkat. Regulasi-regulasi ini bertujuan untuk memfasilitasi masuknya barang-barang penanganan pandemi—termasuk alat pelindung diri (APD), reagen diagnostik, ventilator, obat-obatan, dan vaksin—dengan cepat dan tanpa hambatan fiskal.
            </p>
            <p className="text-base leading-relaxed text-foreground/90 mb-4" style={{ textAlign: 'justify' }}>
              Karakteristik respons kepabeanan COVID-19 yang menonjol adalah kecepatan produksi regulasi namun dengan koordinasi yang kadang tidak optimal. PMK demi PMK diterbitkan, seringkali saling merevisi dalam waktu singkat, mencerminkan ketiadaan kerangka kebijakan darurat yang sistematis.
            </p>

            <h3 className="text-base font-semibold text-foreground mb-3">Kerangka Hukum Kepabeanan COVID-19</h3>
            <div className="table-responsive rounded-lg border border-border mb-3">
              <table className="legal-table">
                <thead>
                  <tr>
                    <th className="w-8">No.</th>
                    <th>PMK</th>
                    <th>Substansi</th>
                    <th>Status</th>
                  </tr>
                </thead>
                <tbody>
                  {kerangkaCovid.map((row) => (
                    <tr key={row.no}>
                      <td className="text-center">{row.no}</td>
                      <td className="font-mono text-xs font-medium">{row.pmk}</td>
                      <td className="text-xs">{row.isi}</td>
                      <td>
                        <span className={`inline-flex px-2 py-0.5 rounded-full text-xs font-medium ${row.status === 'Berlaku' ? 'bg-green-100 text-green-700 dark:bg-green-900/40 dark:text-green-300' : 'bg-gray-100 text-gray-500 dark:bg-gray-800 dark:text-gray-400'}`}>
                          {row.status}
                        </span>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
            <p className="text-xs text-muted-foreground mb-4">Tabel 3. Kerangka Hukum Kepabeanan Pandemi COVID-19 (Sumber: analisis penulis, 2026)</p>

            <div className="p-4 rounded-lg border border-amber-200 dark:border-amber-800 bg-amber-50 dark:bg-amber-950/30">
              <p className="text-sm font-semibold text-amber-800 dark:text-amber-300 mb-2">Analisis Kritis</p>
              <p className="text-sm text-amber-900 dark:text-amber-200">
                Terdapat setidaknya 8 PMK yang diterbitkan terkait COVID-19 dalam rentang 2020–2022, dan banyak di antaranya saling merevisi dalam waktu singkat. Pola ini menunjukkan bahwa Indonesia tidak memiliki mekanisme kepabeanan darurat yang sistematis—setiap perubahan situasi pandemi memerlukan PMK baru, alih-alih dapat ditangani melalui mekanisme yang sudah ada.
              </p>
            </div>
          </section>

          {/* 3A.5 Krisis 2008 */}
          <section id="krisis-2008" className="scroll-mt-20 mb-10">
            <h2 className="text-xl font-bold text-foreground mb-4" style={{ fontFamily: 'var(--font-merriweather)' }}>
              3A.5 Arah Pengaturan Krisis Global 2008
            </h2>
            <p className="text-base leading-relaxed text-foreground/90 mb-4" style={{ textAlign: 'justify' }}>
              Krisis keuangan global 2008 yang dipicu oleh kehancuran pasar subprime mortgage Amerika Serikat berdampak luas pada perekonomian Indonesia. Untuk merespons ancaman kontraksi ekonomi, pemerintah mengeluarkan serangkaian kebijakan stimulus, termasuk melalui instrumen Bea Masuk Ditanggung Pemerintah (BM DTP).
            </p>
            <p className="text-base leading-relaxed text-foreground/90 mb-4" style={{ textAlign: 'justify' }}>
              BM DTP merupakan mekanisme di mana bea masuk yang seharusnya dibayar importir ditanggung oleh pemerintah melalui anggaran negara. Instrumen ini digunakan untuk meringankan beban industri yang mengimpor bahan baku dan barang modal, sehingga dapat mempertahankan produksi dan menjaga lapangan kerja di tengah krisis.
            </p>
            <p className="text-base leading-relaxed text-foreground/90 mb-4" style={{ textAlign: 'justify' }}>
              Di samping BM DTP, pemerintah juga menggunakan instrumen tindakan pengamanan (safeguard) untuk melindungi industri dalam negeri dari lonjakan impor yang dipicu oleh krisis. PMK No. 151/PMK.011/2009 memberikan perlindungan safeguard untuk produk paku, sementara PMK No. 133/PMK.011/2009 memberikan perlindungan untuk dextrose monohydrate.
            </p>

            <h3 className="text-base font-semibold text-foreground mb-3">Daftar 33 PMK BM DTP — Krisis Global 2008</h3>
            <div className="table-responsive rounded-lg border border-border mb-3" style={{ maxHeight: '400px', overflowY: 'auto' }}>
              <table className="legal-table">
                <thead className="sticky top-0 bg-background">
                  <tr>
                    <th className="w-8">No.</th>
                    <th>Nomor PMK</th>
                    <th>Komoditas/Sektor</th>
                  </tr>
                </thead>
                <tbody>
                  {pmkKrisis2008.map((row) => (
                    <tr key={row.no}>
                      <td className="text-center">{row.no}</td>
                      <td className="font-mono text-xs font-medium">{row.pmk}</td>
                      <td className="text-xs">{row.komoditas}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
            <p className="text-xs text-muted-foreground mb-4">Daftar PMK BM DTP dan Safeguard dalam rangka respons Krisis Global 2008 (Sumber: analisis penulis, 2026)</p>
          </section>

          {/* 3A.6 Bencana Nasional */}
          <section id="bencana-nasional" className="scroll-mt-20 mb-10">
            <h2 className="text-xl font-bold text-foreground mb-4" style={{ fontFamily: 'var(--font-merriweather)' }}>
              3A.6 Arah Pengaturan Bencana Nasional
            </h2>
            <p className="text-base leading-relaxed text-foreground/90 mb-4" style={{ textAlign: 'justify' }}>
              Indonesia sebagai negara yang terletak di kawasan "ring of fire" dan pertemuan lempeng tektonik dunia sangat rentan terhadap bencana alam. Serangkaian bencana besar—tsunami Aceh (Desember 2004), gempa Nias (Maret 2005), dan gempa Yogyakarta (Mei 2006)—mendorong pemerintah untuk mengeluarkan regulasi kepabeanan darurat yang bersifat responsif.
            </p>

            <h3 className="text-base font-semibold text-foreground mb-3">PMK Terkait Bencana Nasional</h3>
            <div className="table-responsive rounded-lg border border-border mb-4">
              <table className="legal-table">
                <thead>
                  <tr>
                    <th>PMK</th>
                    <th>Bencana</th>
                    <th>Substansi</th>
                    <th>Status</th>
                  </tr>
                </thead>
                <tbody>
                  {pmkBencana.map((row) => (
                    <tr key={row.pmk}>
                      <td className="font-mono text-xs font-medium">{row.pmk}</td>
                      <td className="text-xs font-medium">{row.bencana}</td>
                      <td className="text-xs">{row.isi}</td>
                      <td>
                        <span className="inline-flex px-2 py-0.5 rounded-full text-xs font-medium bg-green-100 text-green-700 dark:bg-green-900/40 dark:text-green-300">
                          {row.status}
                        </span>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>

            <div className="p-4 rounded-lg border border-border bg-card">
              <h4 className="text-sm font-semibold text-foreground mb-2">Resolusi WCO 2011 tentang Natural Disaster Relief</h4>
              <p className="text-xs text-muted-foreground mb-3">WCO Council Resolution of June 2011 on the Role of Customs in Natural Disaster Relief:</p>
              <ul className="space-y-2">
                {wcoResolutions.map((res, idx) => (
                  <li key={idx} className="flex gap-2 text-xs text-foreground/80">
                    <CheckSquare className="h-3.5 w-3.5 text-green-500 shrink-0 mt-0.5" />
                    <span>{res}</span>
                  </li>
                ))}
              </ul>
            </div>
          </section>

          {/* 3A.7 Krisis Moneter */}
          <section id="krisis-moneter" className="scroll-mt-20 mb-10">
            <h2 className="text-xl font-bold text-foreground mb-4" style={{ fontFamily: 'var(--font-merriweather)' }}>
              3A.7 Arah Pengaturan Krisis Moneter 1999
            </h2>
            <p className="text-base leading-relaxed text-foreground/90 mb-4" style={{ textAlign: 'justify' }}>
              Krisis moneter 1997-1998 yang melanda Indonesia—dengan depresiasi rupiah hingga 80% dan inflasi melonjak di atas 70%—menjadi salah satu bencana ekonomi terbesar dalam sejarah Indonesia. Dalam kondisi ini, kebijakan kepabeanan menghadapi dilema: di satu sisi tekanan untuk meningkatkan penerimaan negara guna menutupi defisit anggaran, di sisi lain kebutuhan untuk memfasilitasi masuknya barang-barang kebutuhan pokok demi mengendalikan inflasi.
            </p>
            <p className="text-base leading-relaxed text-foreground/90 mb-4" style={{ textAlign: 'justify' }}>
              Pada periode 1998-1999, pemerintah mengeluarkan berbagai kebijakan kepabeanan yang bertujuan untuk: (1) menstabilkan harga bahan pokok melalui pembebasan/keringanan bea masuk untuk beras, gula, dan komoditas pangan lainnya; (2) mendorong ekspor non-migas untuk mendapatkan devisa; dan (3) memfasilitasi restrukturisasi industri yang terdampak krisis.
            </p>
            <div className="p-4 rounded-lg border border-border bg-card">
              <p className="text-sm font-semibold mb-2">Regulasi Kunci Era Krisis Moneter</p>
              <ul className="text-sm text-muted-foreground space-y-1.5 list-disc pl-4">
                <li>PP No. 2/1999 — Fasilitas pajak dan kepabeanan untuk industri yang terdampak krisis</li>
                <li>Kepmenkeu No. 440/KMK.01/1999 — Pembebasan bea masuk bahan pokok</li>
                <li>Kepmenkeu No. 441/KMK.01/1999 — Keringanan bea masuk untuk beras impor</li>
                <li>Kepmenkeu No. 550/KMK.05/1999 — Fasilitas kepabeanan dalam rangka pemulihan ekonomi</li>
                <li>Berbagai Kepmenkeu tentang BMDTP komoditas strategis selama 1998-2000</li>
              </ul>
            </div>
          </section>

          {/* 3A.8 Krisis 1985 */}
          <section id="krisis-1985" className="scroll-mt-20 mb-10">
            <h2 className="text-xl font-bold text-foreground mb-4" style={{ fontFamily: 'var(--font-merriweather)' }}>
              3A.8 Arah Pengaturan Krisis Kelembagaan 1985 (Inpres No. 4/1985)
            </h2>
            <p className="text-base leading-relaxed text-foreground/90 mb-4" style={{ textAlign: 'justify' }}>
              Krisis kelembagaan kepabeanan 1985 merupakan salah satu episode paling dramatis dalam sejarah reformasi birokrasi Indonesia. Pada pertengahan dekade 1980-an, Pelabuhan Tanjung Priok—pelabuhan utama Indonesia—dikenal sebagai salah satu pelabuhan paling tidak efisien di dunia. Korupsi, birokrasi berlapis, dan ketidakjelasan prosedur menyebabkan barang-barang tertahan di pelabuhan selama berminggu-minggu bahkan berbulan-bulan.
            </p>

            <LegalQuote title="Inpres No. 4 Tahun 1985 — Kebijakan Kelancaran Arus Barang">
              &ldquo;Dalam rangka menunjang kegiatan ekonomi, khususnya di bidang perdagangan, perlu diadakan penyempurnaan prosedur dan sistem pengurusan barang di pelabuhan dengan mempercepat arus barang melalui penggunaan jasa surveyor swasta internasional...&rdquo;
            </LegalQuote>

            <p className="text-base leading-relaxed text-foreground/90 mb-4" style={{ textAlign: 'justify' }}>
              Instruksi Presiden No. 4 Tahun 1985 merupakan respons radikal terhadap krisis ini: pemerintah mendelegasikan sebagian besar fungsi pemeriksaan fisik barang impor kepada perusahaan surveyor internasional, yakni SGS (Société Générale de Surveillance) yang berbasis di Swiss. Langkah ini secara efektif mengalihtugaskan wewenang yang sebelumnya dipegang DJBC kepada pihak swasta asing.
            </p>
            <p className="text-base leading-relaxed text-foreground/90 mb-4" style={{ textAlign: 'justify' }}>
              Dari perspektif hukum kepabeanan, Inpres 4/1985 menandai paradigma pergeseran radikal: dari pendekatan pemeriksaan fisik yang menyeluruh (comprehensive physical examination) ke pendekatan berbasis kepercayaan dan audit pasca-clearance. Pola ini kelak menjadi inspirasi bagi modernisasi kepabeanan Indonesia pada era reformasi.
            </p>
            <div className="p-4 rounded-lg border border-blue-200 dark:border-blue-800 bg-blue-50 dark:bg-blue-950/30">
              <p className="text-sm font-semibold text-blue-800 dark:text-blue-300 mb-2">Signifikansi Historis</p>
              <p className="text-sm text-blue-900 dark:text-blue-200">
                Inpres 4/1985 adalah contoh pertama dan paling dramatis dari "kondisi darurat kelembagaan" yang memaksa reformasi mendasar sistem kepabeanan Indonesia. Kebijakan ini berlangsung selama hampir satu dekade (1985–1994) sebelum DJBC dipulihkan wewenangnya secara bertahap.
              </p>
            </div>
          </section>
        </div>

        {/* BAGIAN B */}
        <div>
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-emerald-100 dark:bg-emerald-950/40 text-emerald-700 dark:text-emerald-300 text-xs font-semibold mb-6">
            Bagian B — Menuju Hukum Kepabeanan Ideal
          </div>

          {/* Antinomi */}
          <section id="antinomi" className="scroll-mt-20 mb-10">
            <h2 className="text-xl font-bold text-foreground mb-4" style={{ fontFamily: 'var(--font-merriweather)' }}>
              3B.1 Antinomi Pengaturan Bea Masuk
            </h2>
            <p className="text-base leading-relaxed text-foreground/90 mb-4" style={{ textAlign: 'justify' }}>
              Dalam kajian terhadap keseluruhan regulasi kepabeanan yang dikeluarkan dalam kondisi darurat, ditemukan suatu antinomi (pertentangan norma) yang mendasar: terdapat norma-norma yang mewajibkan pemungutan bea masuk (norma fiskal) berhadapan dengan norma-norma yang memberikan pembebasan atau keringanan bea masuk (norma non-fiskal/sosial) dalam kondisi yang sama.
            </p>
            <div className="grid md:grid-cols-2 gap-4 mb-4">
              <div className="p-4 rounded-lg border border-red-200 dark:border-red-800 bg-red-50 dark:bg-red-950/30">
                <h3 className="text-sm font-semibold text-red-700 dark:text-red-300 mb-2">Norma Fiskal (Pemungutan)</h3>
                <ul className="text-xs text-red-800 dark:text-red-200 space-y-1 list-disc pl-4">
                  <li>Pasal 2 UU Kepabeanan: kewajiban bayar bea masuk atas semua impor</li>
                  <li>Pasal 23A UUD 1945: pajak/pungutan memaksa harus berdasarkan UU</li>
                  <li>Prinsip equality sebelum hukum dalam perpajakan</li>
                </ul>
              </div>
              <div className="p-4 rounded-lg border border-green-200 dark:border-green-800 bg-green-50 dark:bg-green-950/30">
                <h3 className="text-sm font-semibold text-green-700 dark:text-green-300 mb-2">Norma Non-Fiskal (Pembebasan)</h3>
                <ul className="text-xs text-green-800 dark:text-green-200 space-y-1 list-disc pl-4">
                  <li>Pasal 25–26 UU Kepabeanan: pembebasan/keringanan bea masuk</li>
                  <li>PMK-PMK darurat: nol bea masuk untuk barang bantuan</li>
                  <li>Amanat negara kesejahteraan: perlindungan masyarakat</li>
                </ul>
              </div>
            </div>
            <p className="text-base leading-relaxed text-foreground/90" style={{ textAlign: 'justify' }}>
              Antinomi ini bukan sekadar konflik teknis normatif, melainkan mencerminkan tegangan fundamental antara dua paradigma yang berbeda: negara sebagai pemungut pajak (fiscal state) versus negara sebagai pelindung masyarakat (welfare state). Penyelesaian antinomi ini memerlukan penegasan hierarki nilai dalam sistem hukum kepabeanan.
            </p>
          </section>

          {/* Makna Darurat */}
          <section className="scroll-mt-20 mb-10">
            <h2 className="text-xl font-bold text-foreground mb-4" style={{ fontFamily: 'var(--font-merriweather)' }}>
              3B.2 Meluruskan Makna &ldquo;Darurat&rdquo;
            </h2>
            <p className="text-base leading-relaxed text-foreground/90 mb-4" style={{ textAlign: 'justify' }}>
              Penelitian ini mengusulkan definisi komprehensif "kondisi darurat" dalam konteks hukum kepabeanan yang mencakup empat kategori utama: (1) bencana alam dan/atau non-alam; (2) keadaan bahaya/darurat militer; (3) krisis ekonomi makro yang signifikan; dan (4) krisis kelembagaan yang mengganggu fungsi kepabeanan secara sistemik.
            </p>
            <div className="p-4 rounded-lg border border-border bg-muted/30">
              <p className="text-sm font-semibold mb-2">Usulan Definisi:</p>
              <LegalQuote>
                &ldquo;Kondisi darurat adalah keadaan yang timbul akibat: (a) bencana alam, bencana non-alam, atau bencana sosial sebagaimana dimaksud dalam peraturan perundang-undangan tentang penanggulangan bencana; (b) keadaan bahaya sebagaimana dimaksud dalam peraturan perundang-undangan tentang keadaan bahaya; (c) krisis ekonomi makro yang ditetapkan oleh Pemerintah; atau (d) keadaan lain yang ditetapkan oleh Presiden—yang mengakibatkan terganggunya keseimbangan antara kepentingan fiskal dan kepentingan kemanusiaan serta pemulihan ekonomi nasional, dan memerlukan respons segera dari sistem kepabeanan.&rdquo;
              </LegalQuote>
            </div>
          </section>

          {/* Menuju Hukum Ideal */}
          <section id="hukum-ideal" className="scroll-mt-20 mb-10">
            <h2 className="text-xl font-bold text-foreground mb-4" style={{ fontFamily: 'var(--font-merriweather)' }}>
              3B.3 Menuju Hukum Kepabeanan Ideal: Lima Prinsip
            </h2>
            <p className="text-base leading-relaxed text-foreground/90 mb-6" style={{ textAlign: 'justify' }}>
              Berdasarkan analisis dinamika historis, kajian komparatif, dan kajian normatif yang telah dilakukan, penelitian ini merumuskan lima prinsip dasar yang harus menjadi fondasi hukum kepabeanan ideal Indonesia dalam kondisi darurat:
            </p>
            <div className="space-y-4">
              {prinsipHukumIdeal.map((item) => (
                <div key={item.no} className="flex gap-4 p-4 rounded-lg border border-border bg-card">
                  <div className="w-8 h-8 rounded-full bg-primary text-primary-foreground text-sm font-bold flex items-center justify-center shrink-0">{item.no}</div>
                  <div>
                    <h3 className="text-sm font-semibold text-foreground mb-1">{item.prinsip}</h3>
                    <p className="text-xs text-muted-foreground leading-relaxed">{item.isi}</p>
                  </div>
                </div>
              ))}
            </div>

            <div className="mt-6 p-5 rounded-xl border border-primary/30 bg-primary/5">
              <h3 className="text-base font-semibold text-foreground mb-3">Pergeseran Paradigma yang Diperlukan</h3>
              <div className="grid sm:grid-cols-3 gap-2 text-sm text-center">
                <div className="p-3 rounded-lg bg-red-50 dark:bg-red-950/30 border border-red-200 dark:border-red-800">
                  <div className="font-semibold text-red-700 dark:text-red-300 text-xs mb-1">DARI</div>
                  <div className="text-foreground font-medium">Fiskal-Oriented</div>
                  <div className="text-xs text-muted-foreground">Revenue maximization</div>
                </div>
                <div className="p-3 rounded-lg bg-primary/10 border border-primary/20 flex items-center justify-center">
                  <div className="text-primary font-bold text-lg">→</div>
                </div>
                <div className="p-3 rounded-lg bg-green-50 dark:bg-green-950/30 border border-green-200 dark:border-green-800">
                  <div className="font-semibold text-green-700 dark:text-green-300 text-xs mb-1">MENUJU</div>
                  <div className="text-foreground font-medium">Service-Oriented</div>
                  <div className="text-xs text-muted-foreground">Welfare facilitation</div>
                </div>
              </div>
            </div>
          </section>
        </div>
      </div>
    </DocsLayout>
  );
}

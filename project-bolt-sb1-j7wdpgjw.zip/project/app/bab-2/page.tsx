import { DocsLayout } from '@/components/docs-layout';
import { LegalQuote } from '@/components/legal-quote';
import { BookMarked } from 'lucide-react';

const negaraPerbandingan = [
  {
    negara: 'Singapura',
    uu: 'Customs Act (Cap. 70)',
    otoritas: 'Singapore Customs',
    paradigma: 'Trade facilitation',
    darurat: 'Mengacu ke Emergency Powers Act; ada prosedur khusus fast-track clearance',
    catatan: 'Paling efisien; integrasi penuh dengan sistem digital',
  },
  {
    negara: 'Australia',
    uu: 'Customs Act 1901',
    otoritas: 'Australian Border Force',
    paradigma: 'Security & facilitation',
    darurat: 'Emergency Management Act; Customs dapat memprioritaskan barang relief',
    catatan: 'Sistem komprehensif dengan emergency import provision',
  },
  {
    negara: 'Inggris',
    uu: 'Taxation (Cross-border Trade) Act 2018',
    otoritas: 'HM Revenue & Customs',
    paradigma: 'Revenue & compliance',
    darurat: 'Civil Contingencies Act 2004; HMRC dapat memberlakukan tarif nol darurat',
    catatan: 'Post-Brexit memperkenalkan fleksibilitas baru',
  },
  {
    negara: 'Amerika Serikat',
    uu: 'Tariff Act of 1930; Trade Act of 1974',
    otoritas: 'CBP (Customs and Border Protection)',
    paradigma: 'Security-first',
    darurat: 'National Emergencies Act; FEMA berkoordinasi dengan CBP untuk impor bantuan',
    catatan: 'Presidential emergency powers sangat kuat',
  },
  {
    negara: 'Korea Selatan',
    uu: 'Customs Act (관세법)',
    otoritas: 'Korea Customs Service',
    paradigma: 'Trade promotion',
    darurat: 'Act on Countermeasures against Natural Disasters; prosedur khusus barang bantuan',
    catatan: 'Pengalaman luas dari Korea War dan bencana alam',
  },
  {
    negara: 'Kanada',
    uu: 'Customs Act; Special Import Measures Act',
    otoritas: 'Canada Border Services Agency',
    paradigma: 'Security & revenue',
    darurat: 'Emergencies Act; dapat menangguhkan tarif impor produk esensial',
    catatan: 'Federalisme mempengaruhi respons bencana',
  },
  {
    negara: 'India',
    uu: 'Customs Act 1962',
    otoritas: 'Central Board of Indirect Taxes and Customs',
    paradigma: 'Revenue-dominant',
    darurat: 'Notification mekanisme; Executive Order untuk pembebasan tarif',
    catatan: 'Pengalaman dari gempa Bhuj 2001 mendorong reformasi',
  },
  {
    negara: 'Indonesia',
    uu: 'UU No. 17/2006 tentang Kepabeanan',
    otoritas: 'DJBC Kementerian Keuangan',
    paradigma: 'Fiskal-dominan',
    darurat: 'Tidak ada ketentuan khusus; respons melalui PMK/PP ad hoc',
    catatan: 'Ketiadaan definisi darurat yang komprehensif menjadi kelemahan utama',
  },
];

export default function Bab2Page() {
  return (
    <DocsLayout>
      <div className="mb-8">
        <div className="flex items-center gap-2 text-sm text-muted-foreground mb-3">
          <BookMarked className="h-4 w-4" />
          <span>Bab II</span>
        </div>
        <h1 className="text-3xl font-bold text-foreground mb-2" style={{ fontFamily: 'var(--font-merriweather)' }}>
          Kajian Pustaka
        </h1>
        <p className="text-muted-foreground">Kerangka teori dan tinjauan umum</p>
      </div>

      <div className="space-y-10">

        {/* Positivisme Hukum */}
        <section id="positivisme" className="scroll-mt-20">
          <h2 className="text-xl font-bold text-foreground mb-4" style={{ fontFamily: 'var(--font-merriweather)' }}>
            2.1 Teori Positivisme Hukum Modern
          </h2>
          <p className="text-base leading-relaxed text-foreground/90 mb-4" style={{ textAlign: 'justify' }}>
            Penelitian ini menggunakan teori positivisme hukum modern sebagai landasan epistemologis dalam mengkaji norma-norma hukum kepabeanan. Dua tokoh utama yang menjadi referensi adalah H.L.A. Hart dan Hans Kelsen, yang masing-masing menawarkan perspektif berbeda namun saling melengkapi.
          </p>

          <h3 className="text-base font-semibold text-foreground mb-2">H.L.A. Hart: Rule of Recognition</h3>
          <p className="text-base leading-relaxed text-foreground/90 mb-4" style={{ textAlign: 'justify' }}>
            Hart dalam karyanya <em>The Concept of Law</em> (1961) membedakan antara <em>primary rules</em> (aturan yang mengatur perilaku) dan <em>secondary rules</em> (aturan tentang aturan). Di antara <em>secondary rules</em>, Hart mengidentifikasi <em>rule of recognition</em>—norma yang menentukan validitas norma-norma lain dalam sistem hukum. Dalam konteks hukum kepabeanan Indonesia, UUD 1945 berfungsi sebagai <em>rule of recognition</em> tertinggi yang melegitimasi seluruh peraturan kepabeanan di bawahnya.
          </p>
          <LegalQuote title="H.L.A. Hart — The Concept of Law (1961)">
            &ldquo;The rule of recognition... will specify some feature or features possession of which by a suggested rule is taken as a conclusive affirmative indication that it is a rule of the group to be supported by the social pressure it exerts.&rdquo;
          </LegalQuote>

          <h3 className="text-base font-semibold text-foreground mt-6 mb-2">Hans Kelsen: Stufenbau Theorie</h3>
          <p className="text-base leading-relaxed text-foreground/90 mb-4" style={{ textAlign: 'justify' }}>
            Kelsen melalui teori <em>Stufenbau</em> (hierarki norma) dalam <em>Pure Theory of Law</em> (1934/1960) memandang sistem hukum sebagai susunan piramida norma yang tersusun secara hierarkis. Setiap norma memperoleh validitasnya dari norma yang lebih tinggi, dan keseluruhan sistem bertumpu pada <em>Grundnorm</em> (norma dasar) yang menjadi fondasi tertinggi.
          </p>
          <p className="text-base leading-relaxed text-foreground/90 mb-4" style={{ textAlign: 'justify' }}>
            Dalam perspektif Kelsen, UUD NRI 1945 merupakan <em>Grundnorm</em> sistem hukum Indonesia. Seluruh peraturan kepabeanan—dari undang-undang hingga Peraturan Menteri Keuangan—harus memperoleh legitimasi dari norma di atasnya dan tidak boleh bertentangan dengan <em>Grundnorm</em> tersebut. Kerangka inilah yang digunakan untuk menganalisis apakah regulasi kepabeanan darurat ad hoc yang dikeluarkan pemerintah memiliki landasan normatif yang kuat.
          </p>
        </section>

        {/* Welfare State */}
        <section id="welfare-state" className="scroll-mt-20">
          <h2 className="text-xl font-bold text-foreground mb-4" style={{ fontFamily: 'var(--font-merriweather)' }}>
            2.2 Teori Negara Kesejahteraan (Welfare State)
          </h2>
          <p className="text-base leading-relaxed text-foreground/90 mb-4" style={{ textAlign: 'justify' }}>
            Konsep <em>welfare state</em> atau negara kesejahteraan berkembang sebagai respons terhadap kegagalan negara liberal-klasik dalam mengatasi ketimpangan sosial dan ekonomi. Dalam negara kesejahteraan, negara memiliki kewajiban aktif untuk menjamin kesejahteraan warganya melalui berbagai intervensi kebijakan, termasuk di bidang ekonomi.
          </p>
          <p className="text-base leading-relaxed text-foreground/90 mb-4" style={{ textAlign: 'justify' }}>
            Indonesia secara konstitusional menganut prinsip negara kesejahteraan, sebagaimana tecermin dalam Pasal 33 dan 34 UUD 1945. Dalam konteks kepabeanan, implikasi negara kesejahteraan adalah bahwa kebijakan bea masuk tidak semata-mata diorientasikan untuk mengumpulkan pendapatan negara, tetapi juga harus menjadi instrumen perlindungan dan peningkatan kesejahteraan masyarakat—terutama dalam kondisi darurat.
          </p>
          <LegalQuote title="Pasal 33 ayat (4) UUD NRI 1945">
            &ldquo;Perekonomian nasional diselenggarakan berdasar atas demokrasi ekonomi dengan prinsip kebersamaan, efisiensi berkeadilan, berkelanjutan, berwawasan lingkungan, kemandirian, serta dengan menjaga keseimbangan kemajuan dan kesatuan ekonomi nasional.&rdquo;
          </LegalQuote>
          <p className="text-base leading-relaxed text-foreground/90 mb-4" style={{ textAlign: 'justify' }}>
            Dalam kondisi darurat—bencana alam, pandemi, atau krisis ekonomi—prinsip negara kesejahteraan mengharuskan negara untuk merespons dengan cepat dan efektif, termasuk melalui pelonggaran kebijakan kepabeanan. Fungsi kepabeanan harus bergeser dari pemungut pajak menjadi fasilitator distribusi bantuan dan pemulihan ekonomi. Inilah yang Prosser sebut sebagai "regulatory welfare state" yang menggunakan regulasi sebagai instrumen kebijakan sosial.
          </p>
        </section>

        {/* Konstitusi Ekonomi */}
        <section id="konstitusi-ekonomi" className="scroll-mt-20">
          <h2 className="text-xl font-bold text-foreground mb-4" style={{ fontFamily: 'var(--font-merriweather)' }}>
            2.3 Teori Konstitusi Ekonomi
          </h2>

          <h3 className="text-base font-semibold text-foreground mb-2">Tony Prosser</h3>
          <p className="text-base leading-relaxed text-foreground/90 mb-4" style={{ textAlign: 'justify' }}>
            Tony Prosser dalam <em>The Economic Constitution</em> (2014) berpendapat bahwa konstitusi ekonomi merupakan seperangkat norma dasar yang mengatur hubungan antara negara, pasar, dan masyarakat dalam pengelolaan sumber daya ekonomi. Prosser menekankan bahwa regulasi ekonomi—termasuk kepabeanan—harus dilihat bukan semata sebagai instrumen fiskal, melainkan sebagai bagian dari kerangka konstitusional yang lebih luas untuk mewujudkan keadilan sosial.
          </p>

          <h3 className="text-base font-semibold text-foreground mb-2">Ngoc Son Bui</h3>
          <p className="text-base leading-relaxed text-foreground/90 mb-4" style={{ textAlign: 'justify' }}>
            Ngoc Son Bui dalam <em>Constitutional Change in the Contemporary World</em> (2016) mengkaji bagaimana konstitusi ekonomi berubah sebagai respons terhadap transformasi global. Perspektif Bui relevan untuk memahami bagaimana perubahan paradigma ekonomi global—dari liberalisme ke neo-liberalisme dan kemudian ke regulasi pasca-krisis—memengaruhi pengaturan kepabeanan di berbagai negara.
          </p>

          <h3 className="text-base font-semibold text-foreground mb-2">Jimly Asshiddiqie</h3>
          <p className="text-base leading-relaxed text-foreground/90 mb-4" style={{ textAlign: 'justify' }}>
            Jimly Asshiddiqie dalam <em>Konstitusi Ekonomi</em> (2016) mengembangkan konsep konstitusi ekonomi dalam konteks Indonesia. Asshiddiqie berpendapat bahwa Pasal 23 hingga Pasal 33 UUD 1945 membentuk "konstitusi ekonomi" Indonesia yang menetapkan prinsip-prinsip dasar pengelolaan ekonomi nasional, termasuk kewenangan perpajakan dan pungutan negara.
          </p>
          <LegalQuote title="Pasal 23A UUD NRI 1945">
            &ldquo;Pajak dan pungutan lain yang bersifat memaksa untuk keperluan negara diatur dengan undang-undang.&rdquo;
          </LegalQuote>
          <p className="text-base leading-relaxed text-foreground/90 mb-4" style={{ textAlign: 'justify' }}>
            Ketentuan Pasal 23A ini memiliki implikasi penting bagi hukum kepabeanan: bea masuk sebagai pungutan negara yang bersifat memaksa harus diatur dengan undang-undang. Ini berarti setiap pembebasan atau keringanan bea masuk—termasuk dalam kondisi darurat—juga harus memiliki dasar hukum undang-undang yang memadai, atau setidaknya delegasi kewenangan yang jelas dari undang-undang tersebut.
          </p>
        </section>

        {/* Tinjauan Kepabeanan */}
        <section id="kepabeanan" className="scroll-mt-20">
          <h2 className="text-xl font-bold text-foreground mb-4" style={{ fontFamily: 'var(--font-merriweather)' }}>
            2.4 Tinjauan Umum Kepabeanan
          </h2>
          <p className="text-base leading-relaxed text-foreground/90 mb-4" style={{ textAlign: 'justify' }}>
            Kepabeanan (customs) secara etimologis berasal dari kata "pabean" yang dalam bahasa Indonesia merujuk pada kantor tempat mengurus bea (cukai). Secara yuridis, kepabeanan didefinisikan dalam Pasal 1 angka 1 UU No. 17 Tahun 2006: <em>"segala sesuatu yang berhubungan dengan pengawasan atas lalu lintas barang yang masuk atau keluar daerah pabean serta pemungutan bea masuk dan bea keluar."</em>
          </p>

          <h3 className="text-base font-semibold text-foreground mb-2">Fungsi Kepabeanan</h3>
          <div className="grid sm:grid-cols-2 gap-3 mb-4">
            {[
              { judul: 'Fungsi Fiskal', isi: 'Mengumpulkan penerimaan negara melalui pemungutan bea masuk, bea keluar, dan pungutan impor/ekspor lainnya (PPN, PPh).' },
              { judul: 'Fungsi Pengawasan', isi: 'Mengawasi lalu lintas barang untuk mencegah penyelundupan, peredaran barang terlarang, dan pelanggaran hak kekayaan intelektual.' },
              { judul: 'Fungsi Perlindungan', isi: 'Melindungi industri dalam negeri dari persaingan tidak sehat melalui tarif dan tindakan pengamanan perdagangan (safeguard, anti-dumping).' },
              { judul: 'Fungsi Fasilitasi', isi: 'Memfasilitasi kelancaran arus perdagangan internasional yang sah demi mendukung pertumbuhan ekonomi nasional.' },
            ].map((f) => (
              <div key={f.judul} className="p-3 rounded-lg border border-border bg-card">
                <div className="text-sm font-semibold text-foreground mb-1">{f.judul}</div>
                <div className="text-xs text-muted-foreground">{f.isi}</div>
              </div>
            ))}
          </div>

          <h3 className="text-base font-semibold text-foreground mb-3">Perbandingan Hukum Kepabeanan Antar Negara</h3>
          <div className="table-responsive rounded-lg border border-border mb-3">
            <table className="legal-table">
              <thead>
                <tr>
                  <th>Negara</th>
                  <th>Undang-Undang</th>
                  <th>Otoritas</th>
                  <th>Paradigma</th>
                  <th>Ketentuan Darurat</th>
                  <th>Catatan</th>
                </tr>
              </thead>
              <tbody>
                {negaraPerbandingan.map((n) => (
                  <tr key={n.negara} className={n.negara === 'Indonesia' ? 'bg-blue-50/50 dark:bg-blue-950/20' : ''}>
                    <td className="font-semibold">{n.negara}</td>
                    <td className="text-xs">{n.uu}</td>
                    <td className="text-xs">{n.otoritas}</td>
                    <td className="text-xs">{n.paradigma}</td>
                    <td className="text-xs">{n.darurat}</td>
                    <td className="text-xs italic">{n.catatan}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          <p className="text-xs text-muted-foreground">Tabel. Perbandingan Hukum Kepabeanan di Berbagai Negara (Sumber: analisis penulis, 2026)</p>

          <h3 className="text-base font-semibold text-foreground mt-6 mb-2">WCO dan Standar Internasional</h3>
          <p className="text-base leading-relaxed text-foreground/90 mb-4" style={{ textAlign: 'justify' }}>
            World Customs Organization (WCO) sebagai badan internasional yang mengkoordinasikan standar kepabeanan global telah mengeluarkan berbagai instrumen yang relevan dengan kepabeanan dalam kondisi darurat. Konvensi Kyoto yang direvisi (Revised Kyoto Convention/RKC) tahun 1999 menetapkan standar prosedur kepabeanan yang efisien dan efektif, termasuk ketentuan-ketentuan yang memungkinkan prosedur darurat dalam situasi khusus.
          </p>
        </section>

        {/* Kondisi Darurat */}
        <section id="kondisi-darurat" className="scroll-mt-20">
          <h2 className="text-xl font-bold text-foreground mb-4" style={{ fontFamily: 'var(--font-merriweather)' }}>
            2.5 Tinjauan Umum Kondisi Darurat
          </h2>
          <p className="text-base leading-relaxed text-foreground/90 mb-4" style={{ textAlign: 'justify' }}>
            Konsep "kondisi darurat" dalam hukum tidak memiliki definisi tunggal yang disepakati secara universal. Dalam hukum ketatanegaraan Indonesia, terdapat beberapa terminologi yang berkaitan dengan kondisi darurat, antara lain: "keadaan bahaya" (Pasal 12 UUD 1945), "keadaan darurat" (UU No. 23/1959 tentang Keadaan Bahaya), "keadaan tertentu" (Perpres), dan "bencana" (UU No. 24/2007 tentang Penanggulangan Bencana).
          </p>
          <LegalQuote title="Pasal 12 UUD NRI 1945">
            &ldquo;Presiden menyatakan keadaan bahaya. Syarat-syarat dan akibatnya keadaan bahaya ditetapkan dengan undang-undang.&rdquo;
          </LegalQuote>
          <div className="mt-4 space-y-3">
            <h3 className="text-base font-semibold text-foreground">Tipologi Kondisi Darurat</h3>
            {[
              { jenis: 'Bencana Alam', contoh: 'Gempa bumi, tsunami, banjir, gunung meletus', contohIndo: 'Aceh 2004, Nias 2005, Yogyakarta 2006, Lombok 2018' },
              { jenis: 'Krisis Kesehatan/Pandemi', contoh: 'Wabah penyakit, epidemi, pandemi', contohIndo: 'COVID-19 (2020-2023)' },
              { jenis: 'Krisis Ekonomi', contoh: 'Krisis keuangan, inflasi ekstrem, kelesuan ekonomi', contohIndo: 'Krisis moneter 1997-1998, krisis global 2008' },
              { jenis: 'Krisis Kelembagaan', contoh: 'Disfungsi birokrasi, korupsi masif, ketidakefisienan sistemik', contohIndo: 'Krisis port clearance 1985' },
            ].map((t) => (
              <div key={t.jenis} className="flex gap-3 p-3 rounded-lg border border-border bg-card">
                <div className="w-1.5 rounded bg-primary/60 shrink-0" />
                <div>
                  <div className="text-sm font-semibold text-foreground">{t.jenis}</div>
                  <div className="text-xs text-muted-foreground mt-0.5">Contoh umum: {t.contoh}</div>
                  <div className="text-xs text-muted-foreground">Indonesia: {t.contohIndo}</div>
                </div>
              </div>
            ))}
          </div>
        </section>

        {/* Tujuan Bernegara */}
        <section id="tujuan-bernegara" className="scroll-mt-20">
          <h2 className="text-xl font-bold text-foreground mb-4" style={{ fontFamily: 'var(--font-merriweather)' }}>
            2.6 Tujuan Bernegara Republik Indonesia
          </h2>
          <p className="text-base leading-relaxed text-foreground/90 mb-4" style={{ textAlign: 'justify' }}>
            Tujuan bernegara Indonesia dirumuskan secara tegas dalam alinea keempat Pembukaan UUD NRI 1945. Empat tujuan negara tersebut merupakan kompas normatif yang harus menjadi tolok ukur dalam menilai dan merumuskan seluruh kebijakan publik, termasuk kebijakan hukum kepabeanan.
          </p>
          <div className="grid sm:grid-cols-2 gap-3">
            {[
              { nomor: '1', tujuan: 'Melindungi Segenap Bangsa', detail: 'Perlindungan fisik, hukum, ekonomi, dan keamanan terhadap seluruh warga negara Indonesia tanpa terkecuali.' },
              { nomor: '2', tujuan: 'Memajukan Kesejahteraan Umum', detail: 'Peningkatan standar hidup melalui pembangunan ekonomi yang berkeadilan dan distribusi sumber daya yang merata.' },
              { nomor: '3', tujuan: 'Mencerdaskan Kehidupan Bangsa', detail: 'Pengembangan kapasitas manusia Indonesia melalui pendidikan, penelitian, dan inovasi.' },
              { nomor: '4', tujuan: 'Ikut Melaksanakan Ketertiban Dunia', detail: 'Berperan aktif dalam menjaga perdamaian internasional berdasarkan kemerdekaan, perdamaian abadi, dan keadilan sosial.' },
            ].map((t) => (
              <div key={t.nomor} className="p-4 rounded-lg border border-border bg-card">
                <div className="w-7 h-7 rounded-full bg-primary/10 text-primary text-sm font-bold flex items-center justify-center mb-2">{t.nomor}</div>
                <div className="text-sm font-semibold text-foreground mb-1">{t.tujuan}</div>
                <div className="text-xs text-muted-foreground">{t.detail}</div>
              </div>
            ))}
          </div>
          <p className="text-base leading-relaxed text-foreground/90 mt-4" style={{ textAlign: 'justify' }}>
            Dalam konteks hukum kepabeanan darurat, tujuan-tujuan ini mengimplikasikan bahwa: (1) pembebasan bea masuk barang bantuan harus mudah dan cepat (tujuan 1); (2) kebijakan tarif harus mendukung pemulihan ekonomi (tujuan 2); (3) impor barang pendidikan dan penelitian harus difasilitasi (tujuan 3); dan (4) kebijakan kepabeanan harus sesuai standar WTO dan WCO (tujuan 4).
          </p>
        </section>
      </div>
    </DocsLayout>
  );
}

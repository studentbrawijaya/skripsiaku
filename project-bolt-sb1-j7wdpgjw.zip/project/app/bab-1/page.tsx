import { DocsLayout } from '@/components/docs-layout';
import { LegalQuote } from '@/components/legal-quote';
import { BookOpen } from 'lucide-react';

const orisinalitasData = [
  {
    no: 1,
    penulis: 'Hisar Nababan & Rekan (2021)',
    judul: 'Evaluasi Kebijakan Kepabeanan di Masa Pandemi COVID-19',
    fokus: 'Evaluasi kebijakan pembebasan bea masuk barang penanganan COVID-19',
    perbedaan: 'Hanya berfokus pada periode pandemi COVID-19, tidak mengkaji dinamika historis dan aspek kondisi darurat secara konseptual',
  },
  {
    no: 2,
    penulis: 'Wahyudi Kumorotomo (2017)',
    judul: 'Reformasi Birokrasi Kepabeanan Indonesia',
    fokus: 'Reformasi kelembagaan dan prosedur kepabeanan DJBC',
    perbedaan: 'Berfokus pada kelembagaan dan prosedur, bukan pada aspek kondisi darurat dalam hukum kepabeanan',
  },
  {
    no: 3,
    penulis: 'Tony Prosser (2010)',
    judul: 'The Economic Constitution',
    fokus: 'Konstitusi ekonomi dan peran negara dalam regulasi ekonomi',
    perbedaan: 'Kajian umum tentang konstitusi ekonomi tanpa spesifik mengkaji kepabeanan Indonesia dalam kondisi darurat',
  },
  {
    no: 4,
    penulis: 'Ngoc Son Bui (2016)',
    judul: 'Constitutional Change in the Contemporary World',
    fokus: 'Perubahan konstitusi ekonomi di berbagai negara',
    perbedaan: 'Kajian komparatif konstitusi ekonomi tanpa fokus pada instrumen kepabeanan Indonesia',
  },
  {
    no: 5,
    penulis: 'Jimly Asshiddiqie (2016)',
    judul: 'Konstitusi Ekonomi',
    fokus: 'Landasan konstitusional pengaturan ekonomi Indonesia',
    perbedaan: 'Kajian konstitusional umum tanpa pembahasan spesifik mengenai kepabeanan dalam kondisi darurat',
  },
];

export default function Bab1Page() {
  return (
    <DocsLayout>
      <div className="mb-8">
        <div className="flex items-center gap-2 text-sm text-muted-foreground mb-3">
          <BookOpen className="h-4 w-4" />
          <span>Bab I</span>
        </div>
        <h1 className="text-3xl font-bold text-foreground mb-2" style={{ fontFamily: 'var(--font-merriweather)' }}>
          Pendahuluan
        </h1>
        <p className="text-muted-foreground">Latar belakang, orisinalitas, rumusan masalah, tujuan, manfaat, dan metode penelitian</p>
      </div>

      <div className="prose-legal space-y-10">
        {/* Latar Belakang */}
        <section id="latar-belakang" className="scroll-mt-20">
          <h2 className="text-xl font-bold text-foreground mb-4" style={{ fontFamily: 'var(--font-merriweather)' }}>
            1.1 Latar Belakang
          </h2>

          <p className="text-base leading-relaxed text-foreground/90 mb-4" style={{ textAlign: 'justify' }}>
            Hukum kepabeanan merupakan instrumen penting dalam sistem hukum ekonomi negara yang mengatur lalu lintas barang melewati batas wilayah pabean suatu negara. Di Indonesia, hukum kepabeanan tidak hanya berfungsi sebagai pengumpul pendapatan negara (fungsi fiskal), namun juga sebagai alat pengawasan, perlindungan industri dalam negeri, dan penegakan peraturan perundang-undangan (fungsi non-fiskal).
          </p>

          <p className="text-base leading-relaxed text-foreground/90 mb-4" style={{ textAlign: 'justify' }}>
            Kondisi darurat—baik berupa bencana alam, krisis ekonomi, pandemi, maupun keadaan genting lainnya—memberikan tekanan luar biasa pada sistem kepabeanan yang ada. Dalam situasi tersebut, negara dituntut untuk bertindak cepat dan tepat dalam mengakomodasi kebutuhan mendesak masyarakat, namun di sisi lain tetap harus menjaga legalitas dan kepastian hukum.
          </p>

          <p className="text-base leading-relaxed text-foreground/90 mb-4" style={{ textAlign: 'justify' }}>
            Sejarah Indonesia mencatat berbagai kondisi darurat yang memengaruhi kebijakan kepabeanan secara signifikan. Dimulai dari krisis kelembagaan 1985 yang mendorong lahirnya Instruksi Presiden No. 4 Tahun 1985 tentang Kebijakan Kelancaran Arus Barang untuk Menunjang Kegiatan Ekonomi, krisis moneter 1997-1998, gempa bumi dan tsunami Aceh 2004, Nias 2005, Yogyakarta 2006, hingga krisis keuangan global 2008 dan yang terbaru: pandemi COVID-19 yang berlangsung dari 2019 hingga 2023.
          </p>

          <p className="text-base leading-relaxed text-foreground/90 mb-4" style={{ textAlign: 'justify' }}>
            Di setiap titik krisis tersebut, pemerintah mengeluarkan berbagai regulasi kepabeanan yang bersifat ad hoc dan responsif. Namun demikian, tidak terdapat kerangka hukum yang sistematis dan komprehensif yang mengatur bagaimana hukum kepabeanan seharusnya beroperasi dalam kondisi darurat. Hal ini menimbulkan pertanyaan mendasar: apakah respons hukum kepabeanan terhadap kondisi darurat di Indonesia selama ini telah sesuai dengan tujuan bernegara sebagaimana diamanatkan Pembukaan UUD NRI 1945?
          </p>

          <LegalQuote title="Pembukaan UUD NRI 1945 — Alinea IV">
            &ldquo;...melindungi segenap bangsa Indonesia dan seluruh tumpah darah Indonesia dan untuk memajukan kesejahteraan umum, mencerdaskan kehidupan bangsa, dan ikut melaksanakan ketertiban dunia yang berdasarkan kemerdekaan, perdamaian abadi dan keadilan sosial...&rdquo;
          </LegalQuote>

          <p className="text-base leading-relaxed text-foreground/90 mb-4" style={{ textAlign: 'justify' }}>
            Undang-Undang No. 17 Tahun 2006 tentang Perubahan atas UU No. 10 Tahun 1995 tentang Kepabeanan (UU Kepabeanan) memuat ketentuan-ketentuan yang berkaitan dengan kondisi darurat, namun tidak secara eksplisit mendefinisikan apa yang dimaksud dengan "darurat" itu sendiri. Pasal 7A ayat (6) menggunakan frasa "keadaan darurat" dalam konteks pembongkaran barang impor dari sarana pengangkut, sedangkan Pasal 25 ayat (1) huruf d mengatur pembebasan bea masuk untuk barang kiriman hadiah/hibah untuk penanggulangan bencana alam—yang merupakan salah satu bentuk kondisi darurat.
          </p>

          <p className="text-base leading-relaxed text-foreground/90 mb-4" style={{ textAlign: 'justify' }}>
            Inkonsistensi dalam penggunaan terminologi dan ketiadaan definisi tunggal tentang "darurat" dalam konteks kepabeanan menciptakan ketidakpastian hukum. Lebih jauh lagi, paradigma kepabeanan Indonesia yang masih dominan bersifat fiskal—yakni menempatkan fungsi penerimaan negara sebagai prioritas utama—seringkali berbenturan dengan kebutuhan respons cepat dan efisien dalam situasi darurat.
          </p>

          <p className="text-base leading-relaxed text-foreground/90 mb-4" style={{ textAlign: 'justify' }}>
            Perbandingan dengan negara-negara lain seperti Singapura, Australia, Amerika Serikat, dan Korea Selatan menunjukkan bahwa negara-negara tersebut telah mengembangkan mekanisme kepabeanan darurat yang lebih sistematis. Beberapa di antaranya bahkan memiliki ketentuan khusus dalam undang-undang kepabeanan yang secara tegas mengatur prosedur, kewenangan, dan batasan tindakan kepabeanan dalam kondisi darurat.
          </p>

          <p className="text-base leading-relaxed text-foreground/90 mb-4" style={{ textAlign: 'justify' }}>
            Bertolak dari kondisi tersebut, penelitian ini berupaya untuk mengkaji secara komprehensif dinamika pengaturan hukum kepabeanan Indonesia dalam kondisi darurat—dari perspektif historis, komparatif, dan normatif—serta merumuskan model pengaturan yang ideal yang selaras dengan tujuan bernegara Republik Indonesia.
          </p>
        </section>

        {/* Orisinalitas */}
        <section id="orisinalitas" className="scroll-mt-20">
          <h2 className="text-xl font-bold text-foreground mb-4" style={{ fontFamily: 'var(--font-merriweather)' }}>
            1.2 Orisinalitas Penelitian
          </h2>
          <p className="text-base leading-relaxed text-foreground/90 mb-4">
            Penelitian ini berbeda dari penelitian-penelitian terdahulu yang telah mengkaji aspek-aspek tertentu dari hukum kepabeanan maupun kondisi darurat. Tabel berikut memperlihatkan perbedaan penelitian ini dengan penelitian-penelitian sebelumnya:
          </p>

          <div className="table-responsive rounded-lg border border-border">
            <table className="legal-table">
              <thead>
                <tr>
                  <th className="w-8">No.</th>
                  <th>Penulis/Tahun</th>
                  <th>Judul</th>
                  <th>Fokus</th>
                  <th>Perbedaan dengan Penelitian Ini</th>
                </tr>
              </thead>
              <tbody>
                {orisinalitasData.map((row) => (
                  <tr key={row.no}>
                    <td className="text-center font-medium">{row.no}</td>
                    <td className="font-medium">{row.penulis}</td>
                    <td className="italic text-sm">{row.judul}</td>
                    <td className="text-sm">{row.fokus}</td>
                    <td className="text-sm">{row.perbedaan}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          <p className="text-xs text-muted-foreground mt-2">Tabel 1. Orisinalitas Penelitian</p>
        </section>

        {/* Rumusan Masalah */}
        <section id="rumusan-masalah" className="scroll-mt-20">
          <h2 className="text-xl font-bold text-foreground mb-4" style={{ fontFamily: 'var(--font-merriweather)' }}>
            1.3 Rumusan Masalah
          </h2>
          <p className="text-base leading-relaxed text-foreground/90 mb-4">
            Berdasarkan uraian latar belakang di atas, penelitian ini merumuskan dua permasalahan utama:
          </p>
          <ol className="list-decimal pl-6 space-y-3 text-base text-foreground/90">
            <li>
              <strong>Bagaimana dinamika pengaturan hukum kepabeanan Indonesia dalam kondisi darurat?</strong>
              
            </li>
            <li>
              <strong>Bagaimana seharusnya pengaturan hukum kepabeanan dalam kondisi darurat yang ideal sesuai dengan tujuan Negara Republik Indonesia?</strong>
            
            </li>
          </ol>
        </section>

        {/* Tujuan Penelitian */}
        <section id="tujuan" className="scroll-mt-20">
          <h2 className="text-xl font-bold text-foreground mb-4" style={{ fontFamily: 'var(--font-merriweather)' }}>
            1.4 Tujuan Penelitian
          </h2>
          <p className="text-base leading-relaxed text-foreground/90 mb-3">Penelitian ini bertujuan untuk:</p>
          <ol className="list-decimal pl-6 space-y-2 text-base text-foreground/90">
            <li>Mendeskripsikan dan menganalisis dinamika pengaturan hukum kepabeanan Indonesia dalam kondisi darurat secara historis dan komparatif.</li>
            <li>Merumuskan konsep pengaturan hukum kepabeanan dalam kondisi darurat yang ideal dan sesuai dengan tujuan bernegara Republik Indonesia.</li>
          </ol>
        </section>

        {/* Manfaat Penelitian */}
        <section id="manfaat" className="scroll-mt-20">
          <h2 className="text-xl font-bold text-foreground mb-4" style={{ fontFamily: 'var(--font-merriweather)' }}>
            1.5 Manfaat Penelitian
          </h2>

          <h3 className="text-base font-semibold text-foreground mb-2">Manfaat Teoritis</h3>
          <ul className="list-disc pl-6 space-y-2 text-base text-foreground/90 mb-4">
            <li>Memberikan kontribusi pada pengembangan ilmu hukum kepabeanan, khususnya pada kajian tentang respons hukum terhadap kondisi darurat.</li>
            <li>Memperkaya pemahaman tentang interaksi antara hukum kepabeanan, konstitusi ekonomi, dan tujuan bernegara dalam sistem hukum Indonesia.</li>
            <li>Memberikan model analisis yang dapat digunakan untuk mengkaji regulasi kepabeanan dalam situasi krisis secara sistematis.</li>
          </ul>

          <h3 className="text-base font-semibold text-foreground mb-2">Manfaat Praktis</h3>
          <ul className="list-disc pl-6 space-y-2 text-base text-foreground/90">
            <li>Memberikan masukan bagi pembentuk undang-undang (DPR dan Pemerintah) dalam melakukan revisi UU Kepabeanan, khususnya terkait ketentuan kondisi darurat.</li>
            <li>Menjadi referensi bagi Kementerian Keuangan dan DJBC dalam merancang kebijakan kepabeanan yang responsif terhadap kondisi darurat.</li>
            <li>Memberikan panduan bagi praktisi hukum, akademisi, dan pemangku kepentingan lainnya dalam memahami dan menginterpretasikan ketentuan kepabeanan dalam kondisi darurat.</li>
          </ul>
        </section>

        {/* Metode Penelitian */}
        <section id="metode" className="scroll-mt-20">
          <h2 className="text-xl font-bold text-foreground mb-4" style={{ fontFamily: 'var(--font-merriweather)' }}>
            1.6 Metode Penelitian
          </h2>

          <div className="grid sm:grid-cols-2 gap-4 mb-6">
            <div className="p-4 rounded-lg border border-border bg-card">
              <h3 className="text-sm font-semibold text-foreground mb-3">Jenis dan Pendekatan</h3>
              <div className="space-y-2 text-sm">
                <div>
                  <span className="font-medium">Jenis:</span>
                  <p className="text-muted-foreground mt-0.5">Penelitian hukum normatif (doctrinal legal research), yaitu penelitian yang mengkaji norma-norma hukum sebagaimana tertulis dalam peraturan perundang-undangan dan putusan pengadilan.</p>
                </div>
                <div>
                  <span className="font-medium">Pendekatan:</span>
                  <ul className="text-muted-foreground mt-0.5 list-disc pl-4 space-y-0.5">
                    <li>Pendekatan peraturan perundang-undangan (statute approach)</li>
                    <li>Pendekatan komparatif (comparative approach)</li>
                    <li>Pendekatan historis (historical approach)</li>
                    <li>Pendekatan konseptual (conceptual approach)</li>
                  </ul>
                </div>
              </div>
            </div>

            <div className="p-4 rounded-lg border border-border bg-card">
              <h3 className="text-sm font-semibold text-foreground mb-3">Bahan Hukum</h3>
              <div className="space-y-2 text-sm">
                <div>
                  <span className="font-medium">Primer:</span>
                  <p className="text-muted-foreground mt-0.5">UUD 1945, UU Kepabeanan, Peraturan Pemerintah, Peraturan Presiden, Peraturan Menteri Keuangan, dan instrumen hukum internasional yang berkaitan.</p>
                </div>
                <div>
                  <span className="font-medium">Sekunder:</span>
                  <p className="text-muted-foreground mt-0.5">Buku teks, jurnal ilmiah, disertasi, laporan penelitian, dan literatur akademik lainnya yang relevan.</p>
                </div>
                <div>
                  <span className="font-medium">Tersier:</span>
                  <p className="text-muted-foreground mt-0.5">Kamus hukum, kamus bahasa Indonesia, ensiklopedia, dan sumber referensi lainnya.</p>
                </div>
              </div>
            </div>
          </div>

          <div className="p-4 rounded-lg border border-border bg-card">
            <h3 className="text-sm font-semibold text-foreground mb-2">Teknik Analisis</h3>
            <p className="text-sm text-muted-foreground">
              Penelitian ini menggunakan teknik analisis <strong className="text-foreground">preskriptif-analitis</strong>. Analisis preskriptif digunakan untuk merumuskan proposisi hukum tentang bagaimana seharusnya pengaturan kepabeanan dalam kondisi darurat. Sedangkan analisis analitis digunakan untuk menguraikan dan memahami norma-norma hukum yang ada, mengidentifikasi inkonsistensi, dan menemukan kekosongan hukum (rechtsvacuum).
            </p>
          </div>
        </section>

        {/* Definisi Konseptual */}
        <section id="definisi" className="scroll-mt-20">
          <h2 className="text-xl font-bold text-foreground mb-4" style={{ fontFamily: 'var(--font-merriweather)' }}>
            1.7 Definisi Konseptual
          </h2>
          <div className="space-y-4">
            {[
              {
                term: 'Kepabeanan',
                def: 'Kepabeanan adalah segala kegiatan pengawasan atas lalu lintas barang yang masuk atau keluar daerah pabean serta pemungutan bea masuk dan bea keluar.',
              },
              {
                term: 'Direktorat Jenderal Bea dan Cukai',
                def: 'Direktorat Jenderal Bea dan Cukai yang selanjutnya disingkat DJBC adalah satuan kerja unit eselon I di bawah Kementerian Keuangan yang mempunyai tugas sebagai petugas pabean.',
              },
              {
                term: 'Konstitusi',
                def: 'Konstitusi adalah peraturan tertulis, kebiasaan, dan konvensi-konvensi kenegaraan yang menentukan susunan dan kedudukan organ-organ negara, mengatur hubungan antar-organ negara dan aturan tentang hubungan organ negara dengan warga negara.',
              },
              {
                term: 'ondisi Darurat',
                def: 'Kondisi darurat adalah kondisi dimana suatu Negara dihadapkan pada ancaman hidup atau mati yang memerlukan tindakan responsif yang dalam keadaan normal tidak mungkin dapat dibenarkan menurut prinsip-prinsip yang dianut oleh negara yang bersangkutan.',
              },
             
            ].map((item) => (
              <div key={item.term} className="flex gap-3">
                <div className="w-1 rounded bg-primary/60 shrink-0 mt-1" />
                <div>
                  <dt className="font-semibold text-foreground">{item.term}</dt>
                  <dd className="text-sm text-muted-foreground mt-0.5">{item.def}</dd>
                </div>
              </div>
            ))}
          </div>
        </section>
      </div>
    </DocsLayout>
  );
}

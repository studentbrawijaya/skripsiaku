import { DocsLayout } from '@/components/docs-layout';
import { Table2 } from 'lucide-react';
import Link from 'next/link';

const tabelItems = [
  {
    id: 'tabel-1',
    nomor: 'Tabel 1',
    judul: 'Orisinalitas Penelitian',
    halaman: 'Bab I — hal. 8-11',
    deskripsi: 'Perbandingan penelitian ini dengan 5 penelitian terdahulu, mencakup fokus, metodologi, dan perbedaan utama.',
    href: '/bab-1#orisinalitas',
  },
  {
    id: 'tabel-2',
    nomor: 'Tabel 2',
    judul: 'Perbedaan Definisi "Darurat" dalam UU Kepabeanan',
    halaman: 'Bab III — hal. 85',
    deskripsi: 'Perbandingan 7 aspek antara Pasal 7A ayat (6) dan Pasal 25 ayat (1) huruf d UU No. 17/2006.',
    href: '/bab-3#frasa-darurat',
  },
  {
    id: 'tabel-3',
    nomor: 'Tabel 3',
    judul: 'Kerangka Hukum Kepabeanan COVID-19',
    halaman: 'Bab III — hal. 99-104',
    deskripsi: 'Daftar 8 PMK yang diterbitkan terkait pandemi COVID-19 periode 2020-2022, beserta substansi dan status berlakunya.',
    href: '/bab-3#covid19',
  },
  {
    id: 'tabel-4',
    nomor: 'Tabel 4',
    judul: 'Perbandingan Hukum Kepabeanan Antar Negara',
    halaman: 'Bab II — hal. 49-55',
    deskripsi: 'Perbandingan 8 negara (Singapura, Australia, Inggris, AS, Korea Selatan, Kanada, India, Indonesia) pada aspek UU, otoritas, paradigma, ketentuan darurat, dan catatan.',
    href: '/bab-2#kepabeanan',
  },
  {
    id: 'tabel-5',
    nomor: 'Tabel 5',
    judul: 'Legal Order Hukum Kepabeanan Indonesia',
    halaman: 'Bab III — hal. 70-79',
    deskripsi: 'Hierarki 6 level norma hukum kepabeanan dari UUD 1945 hingga Perda Kab/Kota, beserta 22 PP, Perpres, Perda, dan putusan MK.',
    href: '/bab-3#legal-order',
  },
  {
    id: 'tabel-6',
    nomor: 'Tabel 6',
    judul: 'Daftar 33 PMK BM DTP — Krisis Global 2008',
    halaman: 'Bab III — hal. 119-122',
    deskripsi: 'Daftar lengkap 33 Peraturan Menteri Keuangan tentang Bea Masuk Ditanggung Pemerintah dan safeguard dalam rangka respons krisis keuangan global 2008.',
    href: '/bab-3#krisis-2008',
  },
  {
    id: 'tabel-7',
    nomor: 'Tabel 7',
    judul: 'PMK Terkait Bencana Nasional',
    halaman: 'Bab III — hal. 130-135',
    deskripsi: 'Daftar PMK yang diterbitkan untuk merespons bencana Aceh 2004, Nias 2005, Yogyakarta 2006, dan regulasi umum bencana alam.',
    href: '/bab-3#bencana-nasional',
  },
];

const allPmkData = [
  { kategori: 'COVID-19', pmk: 'PMK No. 31/PMK.04/2020', isi: 'Pembebasan bea masuk barang penanganan COVID-19', tahun: 2020, status: 'Dicabut' },
  { kategori: 'COVID-19', pmk: 'PMK No. 34/PMK.04/2020', isi: 'Fasilitas kepabeanan dan cukai COVID-19', tahun: 2020, status: 'Dicabut' },
  { kategori: 'COVID-19', pmk: 'PMK No. 68/PMK.04/2020', isi: 'Tata cara fasilitas kepabeanan impor COVID-19', tahun: 2020, status: 'Dicabut' },
  { kategori: 'COVID-19', pmk: 'PMK No. 134/PMK.04/2020', isi: 'Perubahan PMK 68/2020 — perluasan barang dan fasilitas', tahun: 2020, status: 'Dicabut' },
  { kategori: 'COVID-19', pmk: 'PMK No. 188/PMK.04/2020', isi: 'Perubahan PMK 134/2020 — penyesuaian daftar barang', tahun: 2020, status: 'Dicabut' },
  { kategori: 'COVID-19', pmk: 'PMK No. 68/PMK.04/2021', isi: 'Fasilitas impor vaksin COVID-19 dan obat', tahun: 2021, status: 'Dicabut' },
  { kategori: 'COVID-19', pmk: 'PMK No. 92/PMK.04/2021', isi: 'Perpanjangan fasilitas kepabeanan pandemi', tahun: 2021, status: 'Dicabut' },
  { kategori: 'COVID-19', pmk: 'PMK No. 45/PMK.04/2022', isi: 'Pencabutan PMK fasilitas COVID-19', tahun: 2022, status: 'Berlaku' },
  { kategori: 'BM DTP', pmk: 'PMK No. 241/PMK.011/2008', isi: 'BM DTP industri manufaktur', tahun: 2008, status: 'Dicabut' },
  { kategori: 'BM DTP', pmk: 'PMK No. 242/PMK.011/2008', isi: 'BM DTP mesin industri', tahun: 2008, status: 'Dicabut' },
  { kategori: 'BM DTP', pmk: 'PMK No. 243/PMK.011/2008', isi: 'BM DTP peralatan telekomunikasi', tahun: 2008, status: 'Dicabut' },
  { kategori: 'BM DTP', pmk: 'PMK No. 120/PMK.011/2009', isi: 'BM DTP farmasi dan alat kesehatan', tahun: 2009, status: 'Dicabut' },
  { kategori: 'Safeguard', pmk: 'PMK No. 151/PMK.011/2009', isi: 'Safeguard paku', tahun: 2009, status: 'Berakhir' },
  { kategori: 'Safeguard', pmk: 'PMK No. 133/PMK.011/2009', isi: 'Safeguard dextrose monohydrate', tahun: 2009, status: 'Berakhir' },
  { kategori: 'Bencana', pmk: 'PMK No. 44/PMK.04/2005', isi: 'Fasilitas kepabeanan bencana Aceh', tahun: 2005, status: 'Berlaku' },
  { kategori: 'Bencana', pmk: 'PMK No. 97/PMK.04/2005', isi: 'Fasilitas kepabeanan bencana Nias', tahun: 2005, status: 'Berlaku' },
  { kategori: 'Bencana', pmk: 'PMK No. 95/PMK.04/2006', isi: 'Pembebasan bea masuk gempa Yogyakarta', tahun: 2006, status: 'Berlaku' },
  { kategori: 'Bencana', pmk: 'PMK No. 98/PMK.04/2006', isi: 'Pengembalian bea masuk kendaraan rusak (Yogyakarta)', tahun: 2006, status: 'Berlaku' },
  { kategori: 'Bencana', pmk: 'PMK No. 237/PMK.04/2010', isi: 'Perubahan pembebasan bea masuk bencana', tahun: 2010, status: 'Berlaku' },
  { kategori: 'Bencana', pmk: 'PMK No. 69/PMK.04/2012', isi: 'Pembebasan bea masuk bencana alam (general)', tahun: 2012, status: 'Berlaku' },
];

const statusColor: Record<string, string> = {
  'Berlaku': 'bg-green-100 text-green-700 dark:bg-green-900/40 dark:text-green-300',
  'Dicabut': 'bg-gray-100 text-gray-500 dark:bg-gray-800 dark:text-gray-400',
  'Berakhir': 'bg-orange-100 text-orange-600 dark:bg-orange-900/40 dark:text-orange-300',
};

const kategoriColor: Record<string, string> = {
  'COVID-19': 'bg-blue-100 text-blue-700 dark:bg-blue-900/40 dark:text-blue-300',
  'BM DTP': 'bg-amber-100 text-amber-700 dark:bg-amber-900/40 dark:text-amber-300',
  'Safeguard': 'bg-rose-100 text-rose-700 dark:bg-rose-900/40 dark:text-rose-300',
  'Bencana': 'bg-emerald-100 text-emerald-700 dark:bg-emerald-900/40 dark:text-emerald-300',
};

export default function TabelPage() {
  return (
    <DocsLayout>
      <div className="mb-8">
        <div className="flex items-center gap-2 text-sm text-muted-foreground mb-3">
          <Table2 className="h-4 w-4" />
          <span>Data Visual</span>
        </div>
        <h1 className="text-3xl font-bold text-foreground mb-2" style={{ fontFamily: 'var(--font-merriweather)' }}>
          Tabel & Figur
        </h1>
        <p className="text-muted-foreground">Galeri semua tabel dari skripsi</p>
      </div>

      <div className="space-y-10">

        {/* Gallery Navigasi Tabel */}
        <section>
          <h2 className="text-xl font-bold text-foreground mb-5" style={{ fontFamily: 'var(--font-merriweather)' }}>
            Indeks Tabel
          </h2>
          <div className="grid sm:grid-cols-2 gap-4">
            {tabelItems.map((item) => (
              <Link
                key={item.id}
                href={item.href}
                className="group p-4 rounded-xl border border-border bg-card hover:border-primary/50 hover:shadow-sm transition-all"
              >
                <div className="flex items-center gap-2 mb-2">
                  <span className="inline-flex px-2 py-0.5 rounded bg-primary/10 text-primary text-xs font-semibold">{item.nomor}</span>
                  <span className="text-xs text-muted-foreground">{item.halaman}</span>
                </div>
                <h3 className="text-sm font-semibold text-foreground mb-1 group-hover:text-primary transition-colors">{item.judul}</h3>
                <p className="text-xs text-muted-foreground leading-relaxed">{item.deskripsi}</p>
              </Link>
            ))}
          </div>
        </section>

        {/* Figur: Piramida Legal Order */}
        <section>
          <h2 className="text-xl font-bold text-foreground mb-3" style={{ fontFamily: 'var(--font-merriweather)' }}>
            Figur: Piramida Legal Order Kepabeanan Indonesia
          </h2>
          <p className="text-sm text-muted-foreground mb-5">Visualisasi hierarki norma hukum kepabeanan Indonesia berdasarkan UU No. 12/2011 dan teori Stufenbau Kelsen</p>

          <div className="flex flex-col items-center p-6 rounded-xl border border-border bg-card">
            {[
              { label: 'UUD NRI 1945 (Pasal 23A)', bg: 'bg-blue-800 text-white', w: 'w-24' },
              { label: 'Undang-Undang (UU 10/1995 jo. 17/2006 jo. 7/2021)', bg: 'bg-blue-600 text-white', w: 'w-48' },
              { label: 'Peraturan Pemerintah (22 PP)', bg: 'bg-blue-500 text-white', w: 'w-64' },
              { label: 'Peraturan Presiden', bg: 'bg-blue-400 text-white', w: 'w-72' },
              { label: 'Peraturan Daerah Provinsi', bg: 'bg-blue-300 text-blue-900', w: 'w-80' },
              { label: 'Peraturan Daerah Kabupaten/Kota', bg: 'bg-blue-200 text-blue-900', w: 'w-96' },
            ].map((item, idx) => (
              <div key={idx} className="flex justify-center mb-1 w-full">
                <div className={`${item.w} max-w-full ${item.bg} text-xs text-center py-2 px-3 rounded font-medium`}>
                  {idx + 1}. {item.label}
                </div>
              </div>
            ))}
            <p className="text-xs text-muted-foreground mt-4">Sumber: Analisis penulis berdasarkan UU No. 12/2011 jo. UU 15/2019 dan teori Kelsen</p>
            <p className="text-xs text-amber-600 dark:text-amber-400 mt-1">Catatan: Permenkeu/PMK berada di luar hierarki formal sebagai aturan teknis pelaksana</p>
          </div>
        </section>

        {/* Daftar Lengkap PMK */}
        <section>
          <h2 className="text-xl font-bold text-foreground mb-3" style={{ fontFamily: 'var(--font-merriweather)' }}>
            Daftar Peraturan Menteri Keuangan Kepabeanan Darurat
          </h2>
          <p className="text-sm text-muted-foreground mb-5">
            Tabel interaktif seluruh PMK yang dikeluarkan dalam kondisi darurat, dapat disaring berdasarkan kategori dan status.
          </p>

          {/* Legend */}
          <div className="flex flex-wrap gap-2 mb-4">
            {Object.entries(kategoriColor).map(([kat, cls]) => (
              <span key={kat} className={`inline-flex px-2 py-0.5 rounded text-xs font-medium ${cls}`}>{kat}</span>
            ))}
            {Object.entries(statusColor).map(([status, cls]) => (
              <span key={status} className={`inline-flex px-2 py-0.5 rounded-full text-xs font-medium ${cls}`}>{status}</span>
            ))}
          </div>

          <div className="table-responsive rounded-lg border border-border">
            <table className="legal-table">
              <thead>
                <tr>
                  <th>Kategori</th>
                  <th>Nomor PMK</th>
                  <th>Substansi</th>
                  <th>Tahun</th>
                  <th>Status</th>
                </tr>
              </thead>
              <tbody>
                {allPmkData.map((row, i) => (
                  <tr key={i}>
                    <td>
                      <span className={`inline-flex px-2 py-0.5 rounded text-xs font-medium ${kategoriColor[row.kategori] || ''}`}>
                        {row.kategori}
                      </span>
                    </td>
                    <td className="font-mono text-xs">{row.pmk}</td>
                    <td className="text-xs">{row.isi}</td>
                    <td className="text-center text-xs">{row.tahun}</td>
                    <td>
                      <span className={`inline-flex px-2 py-0.5 rounded-full text-xs font-medium ${statusColor[row.status] || ''}`}>
                        {row.status}
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          <p className="text-xs text-muted-foreground mt-2">Total: {allPmkData.length} PMK kepabeanan darurat (Sumber: analisis penulis, 2026)</p>
        </section>

        {/* Perbandingan Paradigma */}
        <section>
          <h2 className="text-xl font-bold text-foreground mb-5" style={{ fontFamily: 'var(--font-merriweather)' }}>
            Figur: Perbandingan Paradigma Kepabeanan
          </h2>
          <div className="table-responsive rounded-lg border border-border">
            <table className="legal-table">
              <thead>
                <tr>
                  <th>Dimensi</th>
                  <th className="text-red-600 dark:text-red-400">Paradigma Fiskal (Lama)</th>
                  <th className="text-green-600 dark:text-green-400">Paradigma Service (Ideal)</th>
                </tr>
              </thead>
              <tbody>
                {[
                  ['Orientasi utama', 'Memaksimalkan penerimaan negara', 'Memfasilitasi perdagangan dan melindungi masyarakat'],
                  ['Fungsi dominan', 'Pemungutan bea masuk/keluar', 'Fasilitasi, pengawasan, dan perlindungan berimbang'],
                  ['Respons darurat', 'Reaktif, ad hoc, parsial', 'Proaktif, sistematis, terencana'],
                  ['Definisi darurat', 'Tidak ada/inkonsisten', 'Komprehensif, tunggal, hierarkis'],
                  ['Mekanisme darurat', 'PMK baru setiap krisis', 'Protokol darurat permanen yang dapat diaktifkan'],
                  ['Paradigma negara', 'Fiscal state', 'Welfare state'],
                  ['Standar internasional', 'Parsial (WTO/WCO)', 'Selaras penuh dengan WCO, WTO, ASEAN'],
                  ['Tujuan bernegara', 'Tidak terhubung langsung', 'Terhubung langsung ke Pembukaan UUD 1945'],
                ].map(([dimensi, lama, ideal]) => (
                  <tr key={dimensi}>
                    <td className="font-semibold text-xs">{dimensi}</td>
                    <td className="text-xs text-red-700 dark:text-red-300 bg-red-50/50 dark:bg-red-950/10">{lama}</td>
                    <td className="text-xs text-green-700 dark:text-green-300 bg-green-50/50 dark:bg-green-950/10">{ideal}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          <p className="text-xs text-muted-foreground mt-2">Tabel. Perbandingan Paradigma Kepabeanan Fiskal vs. Service-Oriented (Sumber: analisis penulis, 2026)</p>
        </section>

      </div>
    </DocsLayout>
  );
}

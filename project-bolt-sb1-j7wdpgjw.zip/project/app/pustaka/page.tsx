import { DocsLayout } from '@/components/docs-layout';
import { FileText } from 'lucide-react';

const bukuReferensi = [
  { penulis: 'Asshiddiqie, Jimly', judul: 'Konstitusi Ekonomi', kota: 'Jakarta', penerbit: 'Kompas', tahun: '2016' },
  { penulis: 'Asshiddiqie, Jimly', judul: 'Pengantar Ilmu Hukum Tata Negara', kota: 'Jakarta', penerbit: 'Rajawali Pers', tahun: '2019' },
  { penulis: 'Bui, Ngoc Son', judul: 'Constitutional Change in the Contemporary World', kota: 'Basingstoke', penerbit: 'Palgrave Macmillan', tahun: '2016' },
  { penulis: 'Dye, Thomas R.', judul: 'Understanding Public Policy', kota: 'New Jersey', penerbit: 'Pearson Education', tahun: '2013' },
  { penulis: 'Fuady, Munir', judul: 'Teori-Teori Besar (Grand Theory) dalam Hukum', kota: 'Jakarta', penerbit: 'Kencana', tahun: '2013' },
  { penulis: 'Hart, H.L.A.', judul: 'The Concept of Law', kota: 'Oxford', penerbit: 'Oxford University Press', tahun: '1961/2012' },
  { penulis: 'Kelsen, Hans', judul: 'Pure Theory of Law (terjemahan Max Knight)', kota: 'Berkeley', penerbit: 'University of California Press', tahun: '1967' },
  { penulis: 'Kelsen, Hans', judul: 'General Theory of Law and State', kota: 'New Jersey', penerbit: 'Transaction Publishers', tahun: '2006' },
  { penulis: 'Marzuki, Peter Mahmud', judul: 'Penelitian Hukum (Edisi Revisi)', kota: 'Jakarta', penerbit: 'Kencana', tahun: '2016' },
  { penulis: 'Mertokusumo, Sudikno', judul: 'Mengenal Hukum: Suatu Pengantar', kota: 'Yogyakarta', penerbit: 'Liberty', tahun: '2003' },
  { penulis: 'Prosser, Tony', judul: 'The Economic Constitution', kota: 'Oxford', penerbit: 'Oxford University Press', tahun: '2014' },
  { penulis: 'Purwito, Ali', judul: 'Kepabeanan: Konsep dan Aplikasi', kota: 'Jakarta', penerbit: 'Mitra Wacana Media', tahun: '2015' },
  { penulis: 'Rahardjo, Satjipto', judul: 'Ilmu Hukum', kota: 'Bandung', penerbit: 'Citra Aditya Bakti', tahun: '2012' },
  { penulis: 'Siahaan, Marihot P.', judul: 'Bea Masuk: Pengertian, Penetapan, Pembayaran, dan Penagihan', kota: 'Jakarta', penerbit: 'PT Elex Media Komputindo', tahun: '2008' },
  { penulis: 'Soekanto, Soerjono', judul: 'Pengantar Penelitian Hukum', kota: 'Jakarta', penerbit: 'UI Press', tahun: '2015' },
  { penulis: 'Syafrudin, Ateng', judul: 'Menuju Penyelenggaraan Pemerintahan Negara yang Bersih dan Bertanggung Jawab', kota: 'Bandung', penerbit: 'Prosiding Gurubesar Fakultas Hukum', tahun: '2000' },
];

const jurnalReferensi = [
  { penulis: 'Hermawan, Sigit', judul: 'Reformasi Birokrasi Kepabeanan dan Cukai di Indonesia', jurnal: 'Jurnal Ilmu Administrasi', vol: '15(2)', tahun: '2018', hal: '89-104' },
  { penulis: 'Kuncoro, Mudrajad', judul: 'Ekonomi Pembangunan: Teori, Masalah, dan Kebijakan', jurnal: 'Jurnal Ekonomi dan Bisnis Indonesia', vol: '19(4)', tahun: '2004', hal: '355-370' },
  { penulis: 'Mustafa, Delly', judul: 'Birokrasi Pemerintahan', jurnal: 'Jurnal Administrasi Publik', vol: '8(1)', tahun: '2013', hal: '1-20' },
  { penulis: 'Nababan, Hisar & Laila Hayati', judul: 'Kebijakan Kepabeanan dalam Penanganan Pandemi COVID-19 di Indonesia', jurnal: 'Jurnal Pajak dan Keuangan Negara', vol: '3(1)', tahun: '2021', hal: '43-58' },
  { penulis: 'Primadani, Riza', judul: 'Analisis Implementasi Kepabeanan Indonesia Menghadapi Era Perdagangan Bebas', jurnal: 'Jurnal Perspektif Bea dan Cukai', vol: '2(1)', tahun: '2018', hal: '1-18' },
  { penulis: 'Prasetio, Dito', judul: 'Fungsi Kepabeanan dalam Sistem Perdagangan Internasional', jurnal: 'Jurnal Hukum Internasional', vol: '10(2)', tahun: '2013', hal: '287-305' },
  { penulis: 'Setiyono, Budi', judul: 'Reformasi Administrasi Pelabuhan dan Dampaknya terhadap Kelancaran Arus Barang', jurnal: 'Jurnal Bisnis dan Ekonomi', vol: '21(1)', tahun: '2014', hal: '76-93' },
  { penulis: 'Sinaga, Edison', judul: 'Analisis Yuridis Pengaturan Bea Masuk dalam Undang-Undang Kepabeanan Indonesia', jurnal: 'Jurnal Legislasi Indonesia', vol: '16(3)', tahun: '2019', hal: '327-344' },
  { penulis: 'Surbakti, Ramlan', judul: 'Memahami Ilmu Politik', jurnal: 'Jurnal Ilmu Politik Indonesia', vol: '5(1)', tahun: '2010', hal: '1-15' },
];

const peraturanReferensi = [
  { jenis: 'Konstitusi', nama: 'Undang-Undang Dasar Negara Republik Indonesia Tahun 1945' },
  { jenis: 'Undang-Undang', nama: 'Undang-Undang No. 10 Tahun 1995 tentang Kepabeanan' },
  { jenis: 'Undang-Undang', nama: 'Undang-Undang No. 17 Tahun 2006 tentang Perubahan atas UU No. 10/1995 tentang Kepabeanan' },
  { jenis: 'Undang-Undang', nama: 'Undang-Undang No. 39 Tahun 2007 tentang Cukai' },
  { jenis: 'Undang-Undang', nama: 'Undang-Undang No. 24 Tahun 2007 tentang Penanggulangan Bencana' },
  { jenis: 'Undang-Undang', nama: 'Undang-Undang No. 7 Tahun 2014 tentang Perdagangan' },
  { jenis: 'Undang-Undang', nama: 'Undang-Undang No. 12 Tahun 2011 tentang Pembentukan Peraturan Perundang-undangan' },
  { jenis: 'Undang-Undang', nama: 'Undang-Undang No. 23 Tahun 1959 tentang Keadaan Bahaya' },
  { jenis: 'Undang-Undang', nama: 'Undang-Undang No. 6 Tahun 2023 tentang Penetapan Perpu No. 2/2022 tentang Cipta Kerja' },
  { jenis: 'Instruksi Presiden', nama: 'Instruksi Presiden No. 4 Tahun 1985 tentang Kebijakan Kelancaran Arus Barang untuk Menunjang Kegiatan Ekonomi' },
  { jenis: 'PMK', nama: 'PMK No. 44/PMK.04/2005 — Fasilitas kepabeanan bencana Aceh' },
  { jenis: 'PMK', nama: 'PMK No. 97/PMK.04/2005 — Fasilitas kepabeanan bencana Nias' },
  { jenis: 'PMK', nama: 'PMK No. 95/PMK.04/2006 — Pembebasan bea masuk gempa Yogyakarta' },
  { jenis: 'PMK', nama: 'PMK No. 98/PMK.04/2006 — Pengembalian bea masuk kendaraan rusak' },
  { jenis: 'PMK', nama: 'PMK No. 133/PMK.011/2009 — Tindakan safeguard dextrose' },
  { jenis: 'PMK', nama: 'PMK No. 151/PMK.011/2009 — Tindakan safeguard paku' },
  { jenis: 'PMK', nama: 'PMK No. 237/PMK.04/2010 — Perubahan pembebasan bea masuk bencana' },
  { jenis: 'PMK', nama: 'PMK No. 69/PMK.04/2012 — Pembebasan bea masuk bencana alam' },
  { jenis: 'PMK', nama: 'PMK No. 31/PMK.04/2020 — Pembebasan bea masuk COVID-19' },
  { jenis: 'PMK', nama: 'PMK No. 34/PMK.04/2020 — Fasilitas kepabeanan COVID-19' },
  { jenis: 'PMK', nama: 'PMK No. 68/PMK.04/2020 — Tata cara fasilitas kepabeanan COVID-19' },
  { jenis: 'PMK', nama: 'PMK No. 134/PMK.04/2020 — Perubahan PMK 68/2020' },
  { jenis: 'PMK', nama: 'PMK No. 188/PMK.04/2020 — Perubahan PMK 134/2020' },
  { jenis: 'PMK', nama: 'PMK No. 68/PMK.04/2021 — Fasilitas impor vaksin dan obat COVID-19' },
  { jenis: 'PMK', nama: 'PMK No. 92/PMK.04/2021 — Perpanjangan fasilitas kepabeanan pandemi' },
  { jenis: 'PMK', nama: 'PMK No. 45/PMK.04/2022 — Pencabutan PMK fasilitas COVID-19' },
];

const internetReferensi = [
  { penulis: 'Direktorat Jenderal Bea dan Cukai', judul: 'Sejarah DJBC', url: 'www.beacukai.go.id', diakses: '10 Januari 2026' },
  { penulis: 'Direktorat Jenderal Bea dan Cukai', judul: 'Laporan Tahunan DJBC 2023', url: 'www.beacukai.go.id/laporan-tahunan', diakses: '15 Januari 2026' },
  { penulis: 'Kementerian Keuangan RI', judul: 'APBN Kita: Kinerja dan Fakta', url: 'www.kemenkeu.go.id', diakses: '12 Februari 2026' },
  { penulis: 'World Customs Organization', judul: 'WCO Council Resolution on the Role of Customs in Natural Disaster Relief (June 2011)', url: 'www.wcoomd.org', diakses: '20 Januari 2026' },
  { penulis: 'World Customs Organization', judul: 'Revised Kyoto Convention — Guidelines', url: 'www.wcoomd.org/rkc', diakses: '20 Januari 2026' },
  { penulis: 'World Trade Organization', judul: 'Agreement on Trade Facilitation', url: 'www.wto.org/tfa', diakses: '25 Januari 2026' },
  { penulis: 'Badan Nasional Penanggulangan Bencana', judul: 'Data Bencana Indonesia 2004-2023', url: 'www.bnpb.go.id', diakses: '8 Februari 2026' },
  { penulis: 'ASEAN Secretariat', judul: 'ASEAN Agreement on Disaster Management and Emergency Response (AADMER)', url: 'www.asean.org', diakses: '30 Januari 2026' },
  { penulis: 'Singapore Customs', judul: 'Emergency Customs Procedures', url: 'www.customs.gov.sg', diakses: '5 Februari 2026' },
  { penulis: 'Australian Border Force', judul: 'Emergency Relief Goods Import', url: 'www.abf.gov.au', diakses: '5 Februari 2026' },
];

export default function PustakaPage() {
  return (
    <DocsLayout>
      <div className="mb-8">
        <div className="flex items-center gap-2 text-sm text-muted-foreground mb-3">
          <FileText className="h-4 w-4" />
          <span>Referensi</span>
        </div>
        <h1 className="text-3xl font-bold text-foreground mb-2" style={{ fontFamily: 'var(--font-merriweather)' }}>
          Daftar Pustaka
        </h1>
        <p className="text-muted-foreground">Sumber referensi yang digunakan dalam penelitian</p>
      </div>

      <div className="space-y-10">

        {/* Buku */}
        <section>
          <h2 className="text-lg font-bold text-foreground mb-4 flex items-center gap-2" style={{ fontFamily: 'var(--font-merriweather)' }}>
            <span className="w-6 h-6 rounded bg-primary/10 text-primary text-xs font-bold flex items-center justify-center">A</span>
            Buku
          </h2>
          <div className="space-y-2">
            {bukuReferensi.map((ref, i) => (
              <div key={i} className="flex gap-3 py-2 border-b border-border/50 last:border-0">
                <div className="text-xs text-muted-foreground w-5 pt-0.5 shrink-0">{i + 1}.</div>
                <p className="text-sm text-foreground/90 leading-relaxed">
                  {ref.penulis}. <em>{ref.judul}</em>. {ref.kota}: {ref.penerbit}, {ref.tahun}.
                </p>
              </div>
            ))}
          </div>
        </section>

        {/* Jurnal */}
        <section>
          <h2 className="text-lg font-bold text-foreground mb-4 flex items-center gap-2" style={{ fontFamily: 'var(--font-merriweather)' }}>
            <span className="w-6 h-6 rounded bg-emerald-100 dark:bg-emerald-900/40 text-emerald-700 dark:text-emerald-300 text-xs font-bold flex items-center justify-center">B</span>
            Jurnal Ilmiah
          </h2>
          <div className="space-y-2">
            {jurnalReferensi.map((ref, i) => (
              <div key={i} className="flex gap-3 py-2 border-b border-border/50 last:border-0">
                <div className="text-xs text-muted-foreground w-5 pt-0.5 shrink-0">{i + 1}.</div>
                <p className="text-sm text-foreground/90 leading-relaxed">
                  {ref.penulis}. &ldquo;{ref.judul}.&rdquo; <em>{ref.jurnal}</em>, Vol. {ref.vol} ({ref.tahun}), hlm. {ref.hal}.
                </p>
              </div>
            ))}
          </div>
        </section>

        {/* Peraturan */}
        <section>
          <h2 className="text-lg font-bold text-foreground mb-4 flex items-center gap-2" style={{ fontFamily: 'var(--font-merriweather)' }}>
            <span className="w-6 h-6 rounded bg-amber-100 dark:bg-amber-900/40 text-amber-700 dark:text-amber-300 text-xs font-bold flex items-center justify-center">C</span>
            Peraturan Perundang-undangan
          </h2>
          <div className="space-y-1">
            {(['Konstitusi', 'Undang-Undang', 'Instruksi Presiden', 'PMK'] as const).map((jenis) => {
              const items = peraturanReferensi.filter(p => p.jenis === jenis);
              if (items.length === 0) return null;
              return (
                <div key={jenis} className="mb-4">
                  <h3 className="text-sm font-semibold text-foreground mb-2 flex items-center gap-1">
                    <span className="w-1.5 h-1.5 rounded-full bg-primary/60 inline-block" />
                    {jenis}
                  </h3>
                  <div className="space-y-1.5 pl-4">
                    {items.map((ref, i) => (
                      <div key={i} className="flex gap-2">
                        <div className="text-xs text-muted-foreground w-5 shrink-0">{i + 1}.</div>
                        <p className="text-sm text-foreground/90">{ref.nama}.</p>
                      </div>
                    ))}
                  </div>
                </div>
              );
            })}
          </div>
        </section>

        {/* Internet */}
        <section>
          <h2 className="text-lg font-bold text-foreground mb-4 flex items-center gap-2" style={{ fontFamily: 'var(--font-merriweather)' }}>
            <span className="w-6 h-6 rounded bg-blue-100 dark:bg-blue-900/40 text-blue-700 dark:text-blue-300 text-xs font-bold flex items-center justify-center">D</span>
            Sumber Internet
          </h2>
          <div className="space-y-2">
            {internetReferensi.map((ref, i) => (
              <div key={i} className="flex gap-3 py-2 border-b border-border/50 last:border-0">
                <div className="text-xs text-muted-foreground w-5 pt-0.5 shrink-0">{i + 1}.</div>
                <p className="text-sm text-foreground/90 leading-relaxed">
                  {ref.penulis}. &ldquo;{ref.judul}.&rdquo; <span className="text-muted-foreground">{ref.url}</span>, diakses {ref.diakses}.
                </p>
              </div>
            ))}
          </div>
        </section>
      </div>
    </DocsLayout>
  );
}

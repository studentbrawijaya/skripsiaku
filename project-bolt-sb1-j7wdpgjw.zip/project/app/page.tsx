import { DocsLayout } from '@/components/docs-layout';
import Link from 'next/link';
import { BookOpen, Scale, Gavel, BookMarked, FileText, Table2, ArrowRight, University, Calendar, User } from 'lucide-react';

const navCards = [
  {
    href: '/bab-1',
    title: 'Bab I',
    subtitle: 'Pendahuluan',
    description: 'Latar belakang, orisinalitas penelitian, rumusan masalah, tujuan, manfaat, metode penelitian, dan definisi konseptual.',
    icon: BookOpen,
    color: 'from-blue-500/20 to-blue-600/10 border-blue-200 dark:border-blue-800',
    iconColor: 'text-blue-600 dark:text-blue-400',
  },
  {
    href: '/bab-2',
    title: 'Bab II',
    subtitle: 'Kajian Pustaka',
    description: 'Teori positivisme hukum, negara kesejahteraan, konstitusi ekonomi, tinjauan kepabeanan, kondisi darurat, dan tujuan bernegara.',
    icon: BookMarked,
    color: 'from-emerald-500/20 to-emerald-600/10 border-emerald-200 dark:border-emerald-800',
    iconColor: 'text-emerald-600 dark:text-emerald-400',
  },
  {
    href: '/bab-3',
    title: 'Bab III',
    subtitle: 'Hasil & Pembahasan',
    description: 'Dinamika pengaturan hukum kepabeanan dari Inpres 1985 hingga pandemi COVID-19, analisis frasa darurat, dan arah hukum ideal.',
    icon: Scale,
    color: 'from-amber-500/20 to-amber-600/10 border-amber-200 dark:border-amber-800',
    iconColor: 'text-amber-600 dark:text-amber-400',
  },
  {
    href: '/bab-4',
    title: 'Bab IV',
    subtitle: 'Penutup',
    description: 'Kesimpulan temuan penelitian dan saran untuk pembenahan regulasi kepabeanan Indonesia ke depan.',
    icon: Gavel,
    color: 'from-rose-500/20 to-rose-600/10 border-rose-200 dark:border-rose-800',
    iconColor: 'text-rose-600 dark:text-rose-400',
  },
  {
    href: '/pustaka',
    title: 'Daftar Pustaka',
    subtitle: 'Referensi',
    description: 'Buku, jurnal ilmiah, peraturan perundang-undangan, dan sumber internet yang digunakan sebagai referensi penelitian.',
    icon: FileText,
    color: 'from-slate-500/20 to-slate-600/10 border-slate-200 dark:border-slate-800',
    iconColor: 'text-slate-600 dark:text-slate-400',
  },
  {
    href: '/tabel',
    title: 'Tabel & Figur',
    subtitle: 'Data Visual',
    description: 'Galeri semua tabel dan figur dari skripsi: perbandingan hukum kepabeanan antar negara, hierarki norma, dan perbandingan definisi darurat.',
    icon: Table2,
    color: 'from-cyan-500/20 to-cyan-600/10 border-cyan-200 dark:border-cyan-800',
    iconColor: 'text-cyan-600 dark:text-cyan-400',
  },
];

export default function HomePage() {
  return (
    <DocsLayout>
      {/* Hero Section */}
      <div className="mb-12">
        <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-primary/10 text-primary text-xs font-medium mb-6">
          <Scale className="h-3.5 w-3.5" />
          Skripsi
        </div>

        <h1
          className="text-3xl sm:text-4xl font-bold text-foreground mb-6 leading-tight"
          style={{ fontFamily: 'var(--font-merriweather), Georgia, serif' }}
        >
          Dinamika Pengaturan Hukum Kepabeanan dalam Kondisi Darurat yang Sesuai dengan Tujuan Negara Republik Indonesia
        </h1>

        <div className="flex flex-wrap gap-4 mb-4 text-sm text-muted-foreground">
          <span className="flex items-center gap-2">
            <User className="h-4 w-4 text-primary" />
            <strong className="text-foreground">Deva Alfianto Supardi</strong> — NIM 235010107011010
          </span>
          <span className="flex items-center gap-2">
            <University className="h-4 w-4 text-primary" />
            Universitas Brawijaya, Fakultas Hukum
          </span>
          <span className="flex items-center gap-2">
            <Calendar className="h-4 w-4 text-primary" />
            2026
          </span>
        </div>

        <div className="p-4 rounded-lg border border-border bg-muted/30 mb-8">
          <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-2">Dosen Pembimbing</p>
          <div className="space-y-1 text-sm text-foreground/90">
            <p>1. <strong>Dr. Shinta Hadiyantina, S.H., M.H.</strong></p>
            <p>2. <strong>Amelia Ayu Paramitha, S.H., M.H.</strong></p>
          </div>
        </div>

        <div className="p-6 rounded-xl border border-border bg-card">
          <h2 className="text-base font-semibold text-foreground mb-3" style={{ fontFamily: 'var(--font-merriweather)' }}>
            Abstrak
          </h2>
          <p className="text-sm text-muted-foreground leading-relaxed mb-3">
            Deva Alfianto Supardi, Hukum Administrasi Negara, Fakultas Hukum Universitas Brawijaya, April 2026, DINAMIKA PENGATURAN HUKUM KEPABEANAN DALAM KONDISI DARURAT YANG SESUAI DENGAN TUJUAN NEGARA REPUBLIK INDONESIA, Dr. Shinta Hadiyantina, S.H., M.H., Amelia Ayu Paramitha S.H., M.H.
          </p>
          <p className="text-sm text-muted-foreground leading-relaxed mb-3">
            Permasalahan dalam penelitian ini berangkat dari adanya ketidakjelasan norma dalam Undang-Undang Kepabeanan terkait frasa “darurat” yang hanya mencakup keadaan force majeure pada sarana pengangkut, sedangkan UUD NRI 1945 mendefinisikan keadaan darurat sebagai state of emergency. Undang-Undang Kepabeanan mengakui keadaan darurat dengan adanya pembebasan bea masuk ketika adanya bencana alam, sementara dalam rezim Undang-Undang Penanggulangan Bencana, bencana itu tidak hanya mencakup bencana alam, melainkan ada juga bencana non-alam, dan bencana sosial. Ketidakjelasan norma “darurat” dalam UU Kepabeanan menimbulkan ketidakpastian hukum.
          </p>
          <p className="text-sm text-muted-foreground leading-relaxed mb-3">
Metode yang digunakan penulis dalam skripsi ini adalah yuridis normatif dengan pendekatan peraturan perundang-undangan, pendekatan konseptual, dan pendekatan perbandingan. Bahan hukum yang digunakan adalah bahan hukum primer, sekunder, dan tersier yang didapatkan dari studi kepustakaan. Analisis bahan hukum dalam skripsi ini dilakukan dengan teknik deskriptif dan teknik interpretatif, khususnya interpretasi sistematis.

          </p>
            <p className="text-sm text-muted-foreground leading-relaxed mb-3">

Penelitian ini bertujuan untuk menganalisis dinamika pengaturan kepabeanan dalam berbagai kondisi darurat serta merumuskan pengaturan hukum kepabeanan dalam kondisi darurat yang sesuai dengan tujuan negara Republik Indonesia. Teori konstitusi ekonomi dalam skripsi ini berfungsi sebagai kerangka berpikir untuk melihat intervensi negara pada sektor kepabeanan dalam kondisi darurat agar selaras dengan konstitusi, sedangkan teori positivisme hukum modern digunakan untuk mengkritisi ketiadaan rule of recognition dan rule of change dalam UU Kepabeanan yang menyebabkan pengaturan hukum kepabeanan dalam kondisi darurat kehilangan kepastian hukum dan melampaui kewenangan yang berasal dari undang-undang.
          </p>
            <p className="text-sm text-muted-foreground leading-relaxed mb-3">

Hasil penelitian menunjukkan bahwa dinamika pengaturan kepabeanan dalam kondisi darurat di Indonesia dari tahun 2006 hingga 2025 bersifat reaktif, temporal, dan sangat bergantung pada inisiatif eksekutif. Instrumen fiskal darurat seperti Bea Masuk Ditanggung Pemerintah (BM DTP) yang tidak dikenal dalam UU Kepabeanan berpotensi tidak sah dan bertentangan dengan Pasal 23A UUD NRI 1945 yang akhirnya dapat menimbulkan ketidakpastian hukum. 
          </p>
<p className="text-sm text-muted-foreground leading-relaxed mb-3">
           Oleh karena itu, pengaturan kepabeanan yang ideal dalam kondisi darurat harus direformulasi dengan mengintegrasikan prinsip legalitas, proporsionalitas, akuntabilitas, transparansi, dan perlindungan hak asasi ke dalam UU Kepabeanan. Reformulasi tersebut mencakup revisi Pasal 25 ayat (1) huruf d, pengakuan eksplisit BM DTP sebagai jenis bea masuk tersendiri, penetapan kriteria objektif keadaan darurat, perubahan paradigma dari enforcement-oriented menjadi service-oriented, serta harmonisasi dengan Revised Kyoto Convention dan Resolusi WCO 2011.
          </p>
          <p className="text-sm text-muted-foreground leading-relaxed mb-3">
     <b>   Kata kunci: Kepabeanan, Keadaan Darurat, Konstitusi Ekonomi </b> 
          </p>
        </div>
      </div>

      {/* Summary Section */}
      <div className="mb-12">
        <h2 className="text-xl font-bold text-foreground mb-6" style={{ fontFamily: 'var(--font-merriweather)' }}>
          Ringkasan Penelitian
        </h2>

        <div className="grid sm:grid-cols-2 gap-4 mb-6">
          <div className="p-4 rounded-lg border border-border bg-card">
            <h3 className="text-sm font-semibold text-foreground mb-2">Rumusan Masalah</h3>
            <ol className="text-sm text-muted-foreground space-y-2 list-decimal pl-4">
              <li>Bagaimana dinamika pengaturan hukum kepabeanan Indonesia dalam kondisi darurat?</li>
              <li>Bagaimana seharusnya pengaturan hukum kepabeanan dalam kondisi darurat yang ideal sesuai dengan tujuan Negara Republik Indonesia?</li>
            </ol>
          </div>

          <div className="p-4 rounded-lg border border-border bg-card">
            <h3 className="text-sm font-semibold text-foreground mb-2">Metode Penelitian</h3>
            <ul className="text-sm text-muted-foreground space-y-1">
              <li><span className="font-medium text-foreground">Jenis:</span> Yuridis Normatif</li>
              <li><span className="font-medium text-foreground">Pendekatan:</span> Komparatif, Historis, Konseptual, Peraturan Perundang-undangan</li>
              <li><span className="font-medium text-foreground">Bahan Hukum:</span> Primer, Sekunder, Tersier</li>
              <li><span className="font-medium text-foreground">Analisis:</span> Preskriptif-Analitis</li>
            </ul>
          </div>
        </div>

        <div className="p-4 rounded-lg border border-amber-200 dark:border-amber-800 bg-amber-50 dark:bg-amber-950/30">
          <h3 className="text-sm font-semibold text-amber-800 dark:text-amber-300 mb-2">Temuan Utama</h3>
          <ul className="text-sm text-amber-900 dark:text-amber-200 space-y-1.5">
            <li className="flex gap-2"><span className="text-amber-500 font-bold mt-0.5">→</span> Terdapat antinomi pengaturan bea masuk antara norma yang bersifat fiskal (pemungutan) dengan non-fiskal (pembebasan/keringanan) dalam kondisi darurat.</li>
            <li className="flex gap-2"><span className="text-amber-500 font-bold mt-0.5">→</span> Frasa "darurat" dalam UU Kepabeanan tidak memiliki definisi tunggal dan konsisten, menimbulkan ketidakpastian hukum.</li>
            <li className="flex gap-2"><span className="text-amber-500 font-bold mt-0.5">→</span> Respons kebijakan kepabeanan terhadap krisis masih bersifat reaktif dan tidak sistematis.</li>
            <li className="flex gap-2"><span className="text-amber-500 font-bold mt-0.5">→</span> Paradigma kepabeanan perlu bergeser dari fiskal-oriented menuju service-oriented demi mewujudkan tujuan bernegara.</li>
          </ul>
        </div>
      </div>

      {/* Navigation Cards */}
      <div>
        <h2 className="text-xl font-bold text-foreground mb-6" style={{ fontFamily: 'var(--font-merriweather)' }}>
          Navigasi Dokumen
        </h2>
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {navCards.map((card) => {
            const Icon = card.icon;
            return (
              <Link
                key={card.href}
                href={card.href}
                className={`group p-5 rounded-xl border bg-gradient-to-br ${card.color} hover:shadow-md transition-all duration-200`}
              >
                <div className="flex items-start justify-between mb-3">
                  <Icon className={`h-6 w-6 ${card.iconColor}`} />
                  <ArrowRight className="h-4 w-4 text-muted-foreground group-hover:translate-x-1 transition-transform" />
                </div>
                <div className="text-xs font-semibold text-muted-foreground mb-0.5">{card.title}</div>
                <div className="text-sm font-bold text-foreground mb-2">{card.subtitle}</div>
                <p className="text-xs text-muted-foreground leading-relaxed">{card.description}</p>
              </Link>
            );
          })}
        </div>
      </div>
    </DocsLayout>
  );
}
